"""Free-agent list for the Lapis league: every free agent rated MUST / STREAM / WATCH from (1) his rest-of-season value to MY roster,
(2) his recent box-score performance (minutes, role, form, luck-adjusted) and (3) what he does for my matchup this week.

Value scale: per-game Value in this league's 13 categories, centred on the average draftable player (0 = average draftable, same scale as the
box-score tab). Rest-of-season value comes from the engine's projection (preseason model blended with real games), the box score only
adjusts it (role, minutes, form) through the walk-forward model fitted in research_daily_signal.py.

Tiers (thresholds are constants below, all shown on the page):
  MUST    he would improve my team for the rest of the season: swapping him for my best-to-drop player raises my depth-weighted team value
          by >= MUST_GAIN, he is healthy enough (>= 60% of the remaining games expected) and, while it is still preseason, his case does not
          rest on preseason box scores alone.
  STREAM  not a must, but worth a short hold: the engine says he raises this week's win chance (best swap >= STREAM_PW), or he has >= 3
          games in the next 7 days and fits the categories I am short in.
  WATCH   a signal that he may become a must: a real minutes jump, a role that is opening (rotation teammates out for a long time), a near miss
          on MUST, a hot run that is not luck, or an injured player returning soon. Each WATCH says what would upgrade him.
  SKIP    a big recent line that the model reads as luck / a one-off (kept in a collapsed list so you know why he is not recommended).
"""
import sys
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_live as L  # noqa: E402
import inseason_value as IV  # noqa: E402

SEASON_END = date(2027, 4, 11)
_NS = len(L.A.SLOTS)
DEPTH_W = [1.0] * _NS + ([0.7, 0.5, 0.3, 0.15, 0.05, 0.05] if _NS == 7 else [0.5, 0.3, 0.15, 0.05])   # how much the n-th best player on my roster counts (daily slots, then the bench)
MUST_GAIN = 0.30          # depth-weighted team Value per game gained by the best swap (calibrated on the live pool, see main())
WATCH_GAIN = 0.12         # a near miss
STREAM_PW = 0.006         # best-swap gain in this week's win chance (0.6 points)
MIN_AVAIL = 0.60          # share of the remaining season he must be expected to play for a MUST
FIT_TILT = 0.35           # category weights tilt toward my weak categories by up to +-35%
BOX_DAYS = 21
MIN_ROLE_MIN = 15.0       # a MUST needs at least this many recent minutes (preseason too, unless last season proves a role)
MUST_MAX_OUT = 3          # days a MUST may still be out (was 7: Ingram, out 6 more days, was a top "Claim" in T27A with at most 1 game this week; longer outs are STASH)
ROLE_MIN = 18.0          # minutes that make a real rotation role


def _u0():
    """sigma_units of the average draftable player: subtracting it centres per-game Value on 0 (the box-score scale)."""
    u = np.zeros(13)
    for i, c in enumerate(L.CATS):
        if c in L.PCT:
            u[i] = L.Q["imp_mean"][c] / L.Q["imp_sd"][c]
        else:
            u[i] = (-1 if c in L.LOWER_BETTER else 1) * L.Q["mean"][c] / L.Q["sd"][c]
    return u


U0 = _u0()
CFG = {"depth": DEPTH_W, "must_rank": 9, "cats": L.CATS, "label": L.LABEL, "bal": L.BAL, "u0": U0, "model": "breakout_model.json", "rescore": None, "proj_from_model": False}


def configure(cats, label, bal, u0, model, rescore=None, proj_from_model=False, depth=None, must_rank=9):
    """Switch the module to another league's categories (the Yahoo 9-cat league): value scale, weights, breakout model file."""
    CFG.update(cats=list(cats), label=dict(label), bal=np.asarray(bal, dtype=float), u0=np.asarray(u0, dtype=float), model=model,
               rescore=rescore, proj_from_model=proj_from_model, depth=list(depth or DEPTH_W), must_rank=must_rank)
    _BM.clear()


def S():
    """Value-scale factor of the breakout model's league versus the 13-cat one (1.0 for ESPN); every Value threshold below is multiplied by it."""
    return float(_bm().get("scale_vs_13", 1.0))


def avail_frac(p, today):
    """Expected share of his remaining games he will be available for: healthy play rate x (1 - share of the season spent injured)."""
    base = p.get("base") or L.P_ACTIVE
    inj = str(p.get("inj") or "ACTIVE").upper()
    left = max(1, (SEASON_END - today).days)
    ret = p.get("ret")
    if inj in ("OUT", "SUSPENSION", "INJURY_RESERVE"):
        if ret:
            out_days = max(0, (ret - today).days)
            return float(base * max(0.0, 1 - out_days / left)), True
        return float(base * 0.25), True
    if ret and ret > today:
        return float(base * max(0.0, 1 - (ret - today).days / left)), True
    return float(base * (0.97 if inj in ("DAY_TO_DAY", "QUESTIONABLE", "DOUBTFUL") else 1.0)), False


def team_value(vals):
    v = sorted(vals, reverse=True)
    return sum(w * x for w, x in zip(CFG["depth"], v))


def _cat_weights(my_z):
    """Balanced G-score weights tilted toward the categories my team is short in (season-long team z), away from those it already owns."""
    tilt = np.array([np.clip(-my_z.get(c, 0.0), -1.5, 1.5) / 1.5 for c in CFG["cats"]])
    return CFG["bal"] * (1 + FIT_TILT * tilt), tilt


def recent_lines(today):
    """Player lines of every finished game in the last BOX_DAYS days (regular season and preseason), with date and preseason flag."""
    import inseason_daily as D
    import inseason_schedule as SCH
    g = SCH.games(include_preseason=True)
    ds = sorted({d.date() for d in g["date"] if today - timedelta(days=BOX_DAYS) <= d.date() <= today})
    frames = []
    for d in ds:
        try:
            raw = D.fetch_day(d)
        except Exception:
            continue
        if raw["lines"]:
            f = pd.DataFrame(raw["lines"])
            f["GAME_DATE"] = d.isoformat()
            f["PRE"] = d < L.SEASON_START
            frames.append(f)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(), D


def box_profiles(today):
    """name-key -> what the last games say: minutes, role, form (Value), luck, the daily model's next-10 projection."""
    df, D = recent_lines(today)
    if df.empty:
        return {}
    logs = D.season_logs(today + timedelta(days=1))
    pr = D.project(df.to_dict("records"), logs)
    if CFG["rescore"]:                                      # another league's categories: recompute V / N / L and the prior Value
        pr = CFG["rescore"](pr, D)
    pr["GAME_DATE"] = df["GAME_DATE"].to_numpy()
    pr["PRE"] = df["PRE"].to_numpy()
    pr["STARTER"] = df["STARTER"].to_numpy()
    out = {}
    for k, g in pr.groupby("k"):
        g = g.sort_values("GAME_DATE")
        last = g.tail(5)
        mins = last["MIN"].to_numpy()
        ok = last["proj"].notna()
        out[k] = {
            "n": int(len(g)), "n5": int(len(last)), "pre": bool(g["PRE"].all()),
            "min5": round(float(mins.mean()), 1), "min_last": round(float(mins[-1]), 1),
            "min_prev": round(float(mins[:-2].mean()), 1) if len(mins) > 2 else None,
            "min_l2": round(float(mins[-2:].mean()), 1), "starts": int(last["STARTER"].sum()),
            "v5": round(float(last["V"].mean()), 2), "v_last": round(float(last["V"].iloc[-1]), 2), "v_max": round(float(last["V"].max()), 2),
            "luck5": round(float(last["L"].mean()), 2), "neutral5": round(float(last["N"].mean()), 2),
            "proj": round(float(last.loc[ok, "proj"].mean()), 2) if ok.any() else None,
            "dmin": round(float(last["dmin"].mean()), 1),
            "prior_min": round(float(last["prior_min"].mean()), 1) if last["prior_min"].notna().any() else None,
            "has_prior": bool(last["has_prior"].all()),
            "prior_src": str(last["prior_src"].iloc[-1]), "prior_last": round(float(last["prior_v"].iloc[-1]), 2) if pd.notna(last["prior_v"].iloc[-1]) else None,
            "usage": round(float(((last["FGA"] + 0.44 * last["FTA"] + last["TOV"]) / last["MIN"] * 36).mean()), 1),
            "line": {c: round(float(last[c].mean()), 1) for c in ("PTS", "OREB", "DREB", "AST", "STL", "BLK", "FG3M", "TOV", "PF")},
            "fg": f"{int(last['FGM'].sum())}/{int(last['FGA'].sum())}", "ft": f"{int(last['FTM'].sum())}/{int(last['FTA'].sum())}",
            "dates": last["GAME_DATE"].tolist(),
        }
    return out


_SCH = {}


def next_games(team, today, days=7):
    """Dates of `team`'s games in the next `days` days (schedule table is read once per build)."""
    import inseason_schedule as SCH
    start = max(today, L.SEASON_START)
    if _SCH.get("key") != start:
        g = SCH.games()
        g = g[(g["date"].dt.date >= start) & (g["date"].dt.date < start + timedelta(days=days))]
        by = {}
        for t_, d_ in zip(g["team"], g["date"].dt.date):
            by.setdefault(t_, []).append(d_)
        _SCH["key"], _SCH["by"] = start, by
    return _SCH["by"].get(team, [])



_BM = {}


def _bm():
    if not _BM:
        import json
        _BM.update(json.loads((L.ROOT / "data" / "research" / CFG["model"]).read_text(encoding="utf-8")))
    return _BM


PLAYABLE_FLOOR = -2.0           # predicted Value per game below which a riser is still not a rotation-worthy fantasy player
OPENING_M = 0.10                # ESPN-listed rotation teammates out: share of team minutes missing today
BO_PRESEASON_CAP = "med"        # preseason rotations are not the regular season the model was fitted on


def predict_bo(b):
    """The breakout model's numbers for one player's last <= 5 games (None below 3 games)."""
    if not b or b["n5"] < 3:
        return None
    m = _bm()
    rookie = 0.0 if b.get("prior_src") == "last season" and b.get("prior_last") is not None else 1.0
    prior_v = b["prior_last"] if not rookie else m["rookie_value"]
    prior_min = b["prior_min"] if (not rookie and b.get("prior_min")) else m["rookie_min"]
    up2 = (b["min_l2"] - b["min_prev"]) if b.get("min_prev") is not None else 0.0
    x = {"prior_v": prior_v, "rookie": rookie, "min5": b["min5"], "dmin": b["min5"] - prior_min, "up2": up2, "N5": b["neutral5"],
         "L5": b["luck5"], "usage": b["usage"], "vac": m["vac_q50"]}        # the model's teammates-out feature is on a different scale than the live list: held neutral
    out = {}
    for t in ("y10", "yros"):
        cf, cp = m["full"][t], m["prior"][t]
        out[t] = (cf["const"] + sum(cf[k] * x[k] for k in m["features"]), cp["const"] + cp["prior_v"] * prior_v + cp["rookie"] * rookie)
    return {"x": x, "rookie": rookie, "prior_v": prior_v, "prior_min": prior_min, "up2": up2,
            "s_ros": out["yros"][0] - out["yros"][1], "s10": out["y10"][0] - out["y10"][1], "pred_ros": out["yros"][0], "pred10": out["y10"][0]}


def breakout(b, vac, pre):
    """Breakout score from the last <= 5 games (research_breakout.py: free-agent-type players 2022-26, walk-forward on 2025-26).
    score_ros / score_10 = what these games add to the prior-only expectation of his Value over the rest of the season / next 10 games.
    Level: HIGH = top 10% of test scores (78% of them really rose by 1.5+ Value vs 22% for the pool), MED = top 25%.
    Type: SHORT = an opening that can close (rotation teammates out) or a run the model does not expect to last; LONG = role and production."""
    pm = predict_bo(b)
    if pm is None:
        return None
    m, sc = _bm(), S()
    x, rookie, prior_v, prior_min, up2 = pm["x"], pm["rookie"], pm["prior_v"], pm["prior_min"], pm["up2"]
    s_ros, s10, pred_ros, pred10 = pm["s_ros"], pm["s10"], pm["pred_ros"], pm["pred10"]
    c_ros, c10 = m["buckets"]["yros"], m["buckets"]["y10"]
    # a rise from -5 to -3 is not a fantasy player: the flag also needs a playable predicted value (>= -2 Value per game on the 13-cat scale)
    level = ("high" if s_ros >= c_ros["cut90"] and pred_ros >= -1.5 * sc else "med" if s_ros >= c_ros["cut75"] and pred_ros >= PLAYABLE_FLOOR * sc else None)
    short_only = level is None and s10 >= c10["cut75"] and pred10 >= PLAYABLE_FLOOR * sc
    if level is None and not short_only:
        return None
    if pre and level == "high":
        level = BO_PRESEASON_CAP
    opening = vac >= OPENING_M
    kind = "short" if (short_only or opening) else "long"
    play = None                                                              # share of such players who really ended >= -1 Value (backtest table)
    for row in sorted(c_ros["useful"], key=lambda r: r["pred_floor"]):
        if pred_ros >= row["pred_floor"] and row["ended_ge_-1"] is not None:
            play = row["ended_ge_-1"]
    drivers = []
    if x["dmin"] >= 4:
        drivers.append(f"minutes {b['min5']:.0f} vs {prior_min:.0f} usual" + (" (rookie / new: no history)" if rookie else ""))
    if x["N5"] - prior_v >= 1.2 * sc:
        drivers.append(f"production with luck removed {x['N5']:+.1f} vs {prior_v:+.1f} last season")
    if x["usage"] >= 24:
        drivers.append(f"high usage ({x['usage']:.0f} shot/TO plays per 36)")
    if up2 >= 5:
        drivers.append(f"minutes still rising ({b['min_l2']:.0f} last 2 vs {b['min_prev']:.0f} before)")
    if opening:
        drivers.append("teammates out: the opening may close when they return")
    if rookie and not drivers:
        drivers.append("rookie / new: no history")
    return {"level": level or "short", "kind": kind, "score": round(float(s_ros), 2), "score10": round(float(s10), 2),
            "pred_ros": round(float(pred_ros), 2), "pred10": round(float(pred10), 2), "n": b["n5"], "pre": bool(b["pre"]),
            "drivers": drivers, "vac": round(float(vac), 3), "playable": play}


def build_fa(me, fa_pl, wk, stream_rows, plan_names, league, today, adds_left, my_z=None):
    """me / fa_pl: engine player dicts (name, team, elig, p, base, ret, inj, r, u, src, own, status, avail_from).
    stream_rows: every add/drop row from streaming() (for the best d_pwin per free agent). plan_names: free agents the streaming planner uses."""
    if my_z is None:
        my_z = next((t["z"] for t in league["teams"] if t["is_me"]), {})
    wts, tilt = _cat_weights(my_z)
    cats, label, sc = CFG["cats"], CFG["label"], S()
    try:
        box = box_profiles(today)
    except Exception as e:
        print("FA box profiles failed:", type(e).__name__, e)
        box = {}
    pre = today < L.SEASON_START

    def prof(p):
        u = p["u"] - CFG["u0"]
        f, hurt = avail_frac(p, today)
        return {"u": u, "val": float((u * CFG["bal"]).sum()), "valf": float((u * wts).sum()), "avail": f, "injured": hurt}

    mine = {p["name"]: prof(p) for p in me}
    for p in me:
        m = mine[p["name"]]
        m["eff"] = m["valf"] * m["avail"] if m["valf"] >= 0 else m["valf"]
    base_team = team_value([m["eff"] for m in mine.values()])
    best_pw, best_row = {}, {}
    for r in stream_rows:
        best_pw[r["add"]] = max(best_pw.get(r["add"], -9), r["d_pwin"])
        if r["d_pwin"] >= best_pw[r["add"]]:
            best_row[r["add"]] = r
    abs_long = {}
    for team, lst in L.ABSENT.items():
        outs = [y for y in lst if y["inj"] == "OUT" and (y["ret"] is None or (y["ret"] - today).days >= 14)]
        if outs:
            abs_long[team] = outs

    rows = []
    for f in fa_pl:
        k = L.norm(f["name"])
        pf = prof(f)
        b = box.get(k)
        try:
            vac = L.absence_m(f["team"], k, today, today)[0]
        except Exception:
            vac = 0.0
        if CFG["proj_from_model"] and b:                           # no league-specific daily model: the breakout model's next-10 estimate stands in
            pm = predict_bo(b)
            b["proj"] = round(float(pm["pred10"]), 2) if pm else None
        bo = breakout(b, vac, pre or bool(b and b["pre"]))
        if bo and not bo["pre"]:                                   # real games: half of the gap to the box-score model's rest-of-season value
            delta = float(np.clip(0.5 * (bo["pred_ros"] - pf["val"]), -2.0 * sc, 3.0 * sc))
            pf["val"] += delta
            pf["valf"] += delta
        eff = pf["valf"] * pf["avail"] if pf["valf"] >= 0 else pf["valf"]
        # best player to drop: the swap that leaves my depth-weighted team value highest
        best = None
        for d in me:
            vals = [mine[q["name"]]["eff"] for q in me if q["name"] != d["name"]] + [eff]
            gain = team_value(vals) - base_team
            if best is None or gain > best[0]:
                best = (gain, d)
        gain, drop = best
        # the gain he would add if healthy (for injured stashes)
        eff_h = pf["valf"] * (f.get("base") or L.P_ACTIVE) if pf["valf"] >= 0 else pf["valf"]
        gain_h = max(team_value([mine[q["name"]]["eff"] for q in me if q["name"] != d["name"]] + [eff_h]) - base_team for d in me) if pf["injured"] else gain
        dd = (pf["u"] - mine[drop["name"]]["u"])
        helps = [label[c] for c in sorted(cats, key=lambda c: -dd[cats.index(c)]) if dd[cats.index(c)] >= 0.35][:4]
        hurts = [label[c] for c in sorted(cats, key=lambda c: dd[cats.index(c)]) if dd[cats.index(c)] <= -0.35][:3]
        need_help = [label[c] for c in cats if tilt[cats.index(c)] >= 0.4 and pf["u"][cats.index(c)] >= 0.35]
        g7 = next_games(f["team"], today)
        pw = best_pw.get(f["name"])
        rank_in_mine = 1 + sum(1 for m in mine.values() if m["eff"] > eff)
        rec = {"name": f["name"], "team": f["team"], "pos": "/".join(sorted(f["elig"], key=lambda x: ["PG", "SG", "SF", "PF", "C"].index(x) if x in ["PG", "SG", "SF", "PF", "C"] else 9)),
               "own": f.get("own"), "inj": f["inj"], "ret": str(f["ret"]) if f.get("ret") else None,
               "note": (f.get("news") or {}).get("comment"), "status": f.get("status"), "waiver": f.get("avail_from"),
               "val": round(pf["val"], 2), "valf": round(pf["valf"], 2), "avail": round(pf["avail"], 2), "gain": round(gain, 2),
               "gain_h": round(gain_h, 2), "drop": drop["name"], "rank_in_mine": rank_in_mine, "helps": helps, "hurts": hurts,
               "need_help": need_help, "d_pwin": None if pw is None else round(float(pw), 4), "g7": len(g7),
               "g7_days": [d.strftime("%a %d") for d in g7], "src": f["src"], "box": b, "in_plan": f["name"] in plan_names, "bo": bo,
               "when": (best_row.get(f["name"]) or {}).get("when"), "hold": (best_row.get(f["name"]) or {}).get("hold"),
               "swap_drop": (best_row.get(f["name"]) or {}).get("drop")}
        rec["tier"], rec["why"], rec["upgrade"] = classify(rec, pre, adds_left, abs_long.get(f["team"]), today)
        rec["stash"] = rec["tier"] == "WATCH" and rec["inj"] != "ACTIVE" and rec["gain_h"] >= MUST_GAIN * sc
        rec["score"] = _score(rec)
        rows.append(rec)
    return trim(rows, mine, base_team)


def _score(r):
    """Order inside a tier: MUST by team gain, STREAM by this week's win-chance gain, WATCH by how much real evidence (stashes first)."""
    if r["tier"] == "MUST":
        return r["gain"]
    if r["tier"] == "STREAM":
        return (r["d_pwin"] or 0) * 100 + r["g7"] * 0.05 + r["valf"] * 0.05
    if r["tier"] == "WATCH" and r.get("bo"):
        return 10 + r["bo"]["score"]
    if r["tier"] == "WATCH":
        return (3 if r["stash"] else 0) + len(r["why"]) * 0.5 + max(r["gain"], 0) + (0.3 if r["box"] and not r["box"]["pre"] else 0)
    return r["val"]


def trim(rows, mine, base_team):
    keep = {"MUST": 99, "STREAM": 25, "WATCH": 40, "SKIP": 8}
    out = []
    for t, n in keep.items():
        out += sorted([r for r in rows if r["tier"] == t], key=lambda r: -r["score"])[:n]
    near = sorted([r for r in rows if r["inj"] == "ACTIVE" and r["tier"] != "SKIP"], key=lambda r: -r["gain"])[:6]
    mv = sorted(((m["eff"], n) for n, m in mine.items()), reverse=True)
    return {"rows": out, "near": [r["name"] for r in near], "near_rows": [{"name": r["name"], "gain": r["gain"]} for r in near], "n_pool": len(rows),
            "breakout": {"cut90": _bm()["buckets"]["yros"]["cut90"], "cut75": _bm()["buckets"]["yros"]["cut75"], "n_test": _bm()["n_test"],
                 "top10": _bm()["buckets"]["yros"]["buckets"][1], "base": _bm()["buckets"]["yros"]["base_rate"]},
            "thresholds": {"must_gain": MUST_GAIN * S(), "watch_gain": WATCH_GAIN * S(), "stream_pw": STREAM_PW, "min_avail": MIN_AVAIL},
            "mine": [{"name": n, "eff": round(e, 2)} for e, n in mv]}


def classify(r, pre, adds_left, long_out, today):
    b = r["box"]
    why, up = [], []
    sc = S()
    must_g, watch_g = MUST_GAIN * sc, WATCH_GAIN * sc
    healthy = r["avail"] >= MIN_AVAIL * L.P_ACTIVE
    bx_pre = bool(b and b["pre"])
    bo = r.get("bo")
    # ---- SKIP: a big night / week that the model reads as luck or noise
    if not bo and b and b["v_max"] >= 6 * sc and b["proj"] is not None and b["proj"] < 0.5 * sc and r["gain"] < watch_g and b["min5"] < 24:
        return "SKIP", [f"best recent Value {b['v_max']:.1f} but the model expects {b['proj']:+.1f} over his next 10 games (luck {b['luck5']:+.1f}, {b['min5']:.0f} min)"], []
    # ---- not playable soon: no NBA team (cut, may sign elsewhere or go overseas) or out more than 2 weeks. Opening-night review 2026-10-21:
    #      Kevin Porter Jr. (cut, no team) and Porzingis (out to Dec 1) were MUST claims that would have burned a roster spot on zero games.
    if r["gain"] >= must_g and healthy and r["rank_in_mine"] <= CFG["must_rank"]:
        out_days = (date.fromisoformat(r["ret"]) - today).days if r.get("ret") else 0
        if r["team"] in ("FA", "", None):
            return "WATCH", [f"would add {r['gain']:+.2f} team value, but he has no NBA team right now (no games to count)"], ["signs with a team and starts getting 20+ minutes"]
        # Julian Reese (2026-10-29): MUST on last-season stats with 6 min in 3 preseason games; the preseason exemption below let him through
        if b and b["n5"] >= 2 and b["min5"] < MIN_ROLE_MIN and not (bx_pre and (b.get("prior_min") or 0) >= ROLE_MIN):
            return "WATCH", [f"would add {r['gain']:+.2f} team value on paper, but he plays only {b['min5']:.0f} minutes a game and has no proven role"], ["gets 20+ minutes in real games"]
        if r["inj"] in ("OUT", "SUSPENSION", "INJURY_RESERVE") and out_days > MUST_MAX_OUT:
            return "WATCH", [f"would add {r['gain']:+.2f} team value once back, but he is out {out_days} more days"], [f"returns (listed {r['ret']})"]
    # ---- MUST
    if r["gain"] >= must_g and healthy and r["rank_in_mine"] <= CFG["must_rank"]:
        why.append(f"projects {r['val']:+.1f} Value per game; swapping him for {r['drop']} adds {r['gain']:+.2f} to your depth-weighted team value")
        if r["helps"]:
            why.append("adds " + ", ".join(r["helps"]) + (" (you are short in " + ", ".join(r["need_help"]) + ")" if r["need_help"] else ""))
        if r["hurts"]:
            why.append("costs " + ", ".join(r["hurts"]) + " versus " + r["drop"])
        if b and b["proj"] is not None and b["proj"] < r["val"] - 2.5 * sc and not bx_pre:
            return "WATCH", why + [f"but his recent games project only {b['proj']:+.1f}: the role looks smaller than the preseason model assumed"], ["plays 24+ minutes again"]
        if b and not bx_pre and b["min5"] < 12 and b["n5"] >= 3:
            return "WATCH", why + [f"averages only {b['min5']:.0f} minutes lately"], ["back to 20+ minutes"]
        return "MUST", why, []
    # ---- STREAM: this week's win chance, or a good schedule
    stream_ok = adds_left > 0 and r["inj"] in ("ACTIVE", "DAY_TO_DAY") and healthy
    if stream_ok and (r["d_pwin"] or 0) >= STREAM_PW:
        if r.get("when"):
            why.append(f"if you add him {r['when']}" + (f" and keep him {r['hold']} day{'s' if r['hold'] > 1 else ''}" if r.get("hold") else "") +
                       f" (replacing {r.get('swap_drop')}), this week's win chance rises by {r['d_pwin'] * 100:.1f} pts")
        else:
            why.append(f"best swap raises this week's win chance by {r['d_pwin'] * 100:.1f} pts")
        if r["in_plan"]:
            why.append("used by the day-by-day streaming plan")
        if r["helps"]:
            why.append("helps " + ", ".join(r["helps"]))
        return "STREAM", why, []
    if stream_ok and r["g7"] >= 3 and r["valf"] >= -0.5 * sc and r["gain"] >= -0.05 * sc:
        why.append(f"{r['g7']} games in the next 7 days ({', '.join(r['g7_days'])})")
        if r["need_help"]:
            why.append("fits what you are short in: " + ", ".join(r["need_help"]))
        elif r["helps"]:
            why.append("helps " + ", ".join(r["helps"]))
        return "STREAM", why, []
    # ---- WATCH
    sig = []
    if bo:
        kind = "short-term (an opening)" if bo["kind"] == "short" else "long-term (role and production)"
        sig.append(f"BREAKOUT {kind}: these {bo['n']} games add {bo['score']:+.1f} Value to his rest-of-season outlook; "
                   + "; ".join(bo["drivers"][:3]))
        up.append(f"his minutes and production hold for 5 more games (the model then sees {bo['pred_ros']:+.1f} Value per game)"
                  if bo["kind"] == "long" else "the teammates stay out, or he keeps this role when they return")
    if b and b["n5"] >= 2 and b["dmin"] >= 5 and b["min5"] >= ROLE_MIN and r["valf"] >= -2.6 * sc:
        sig.append(f"minutes up: {b['min5']:.0f} per game vs usual {b['prior_min']:.0f}" if b["prior_min"] else f"{b['min5']:.0f} minutes per game")
        up.append("keeps 22+ minutes over the next 3 games (a role that holds is worth +0.05 Value per minute)")
    if b and b["min_prev"] is not None and b["min_l2"] - b["min_prev"] >= 6 and b["min_l2"] >= ROLE_MIN and r["valf"] >= -2.6 * sc:
        sig.append(f"last two games {b['min_l2']:.0f} min vs {b['min_prev']:.0f} before")
        up.append("minutes stay up in the next 2 games")
    if b and b["proj"] is not None and b["proj"] >= 1.0 * sc and b["luck5"] < 1.5 * sc and r["gain"] >= watch_g:
        sig.append(f"recent games project {b['proj']:+.1f} over the next 10 (not luck: shooting luck {b['luck5']:+.1f})")
        up.append("a few more games like this; the projection updates every refresh")
    if long_out and r["inj"] == "ACTIVE" and r["valf"] >= -1.8 * sc and (not b or b["min5"] < 26) and r["gain"] >= -0.15 * sc:
        names = ", ".join(y["name"] for y in long_out[:2])
        sig.append(f"{names} out for a long time, so his team has minutes to give")
        up.append("he starts getting 22+ minutes")
    if r["gain"] >= watch_g and not (r["gain"] >= must_g):
        sig.append(f"close: team value {r['gain']:+.2f} vs {must_g:.2f} needed for a must")
        up.append("a hot week or an injury on your roster would push him over")
    if r["inj"] not in ("ACTIVE",) and r["gain_h"] >= must_g:
        when = f"back {r['ret']}" if r["ret"] else "no return date"
        sig.append(f"a must when healthy (+{r['gain_h']:.2f}); {r['inj'].replace('_', ' ').lower()}, {when}")
        up.append("a return date within two weeks, or he is activated")
    if sig:
        if pre and bx_pre:
            sig.append("based on preseason games: minutes and rotations are not reliable yet")
        return "WATCH", sig, up[:2]
    return "", [], []
