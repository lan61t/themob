"""Free-agent list for the Lapis league: every free agent rated MUST / STREAM / WATCH from (1) his rest-of-season value to MY roster,
(2) his recent box-score performance (minutes, role, form, luck-adjusted) and (3) what he does for my matchup this week.

Value scale: per-game Value in this league's 13 categories, centred on the average draftable player (0 = average draftable, same scale as the
box-score tab). Rest-of-season value comes from the engine's projection (preseason model blended with real games), the box score only
adjusts it (role, minutes, form) through the walk-forward model fitted in research_daily_signal.py.

Tiers (thresholds are constants below, all shown on the page):
  MUST    he would improve my team for the rest of the season: swapping him for my best-to-drop player raises my depth-weighted team value
          by >= MUST_GAIN, he is healthy enough (>= 60% of the remaining games expected) and, while it is still preseason, his case does not
          rest on preseason box scores alone.
  STREAM  not a must, but worth a short hold: the engine says he raises this week's win chance (best swap >= STREAM_PW), or he has >= 3
          games in the next 7 days and fits the categories I am short in.
  WATCH   a signal that he may become a must: a real minutes jump, a role that is opening (rotation teammates out for a long time), a near miss
          on MUST, a hot run that is not luck, or an injured player returning soon. Each WATCH says what would upgrade him.
  SKIP    a big recent line that the model reads as luck / a one-off (kept in a collapsed list so you know why he is not recommended).
"""
import sys
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_live as L  # noqa: E402
import inseason_value as IV  # noqa: E402

SEASON_END = date(2027, 4, 11)
DEPTH_W = [1.0] * 7 + [0.7, 0.5, 0.3, 0.15, 0.05, 0.05]       # how much the n-th best player on my roster counts (7 daily slots, rotation of ~9)
MUST_GAIN = 0.30          # depth-weighted team Value per game gained by the best swap (calibrated on the live pool, see main())
WATCH_GAIN = 0.12         # a near miss
STREAM_PW = 0.006         # best-swap gain in this week's win chance (0.6 points)
MIN_AVAIL = 0.60          # share of the remaining season he must be expected to play for a MUST
FIT_TILT = 0.35           # category weights tilt toward my weak categories by up to +-35%
BOX_DAYS = 21
ROLE_MIN = 18.0           # minutes that make a real rotation role


def _u0():
    """sigma_units of the average draftable player: subtracting it centres per-game Value on 0 (the box-score scale)."""
    u = np.zeros(13)
    for i, c in enumerate(L.CATS):
        if c in L.PCT:
            u[i] = L.Q["imp_mean"][c] / L.Q["imp_sd"][c]
        else:
            u[i] = (-1 if c in L.LOWER_BETTER else 1) * L.Q["mean"][c] / L.Q["sd"][c]
    return u


U0 = _u0()


def avail_frac(p, today):
    """Expected share of his remaining games he will be available for: healthy play rate x (1 - share of the season spent injured)."""
    base = p.get("base") or L.P_ACTIVE
    inj = str(p.get("inj") or "ACTIVE").upper()
    left = max(1, (SEASON_END - today).days)
    ret = p.get("ret")
    if inj in ("OUT", "SUSPENSION", "INJURY_RESERVE"):
        if ret:
            out_days = max(0, (ret - today).days)
            return float(base * max(0.0, 1 - out_days / left)), True
        return float(base * 0.25), True
    if ret and ret > today:
        return float(base * max(0.0, 1 - (ret - today).days / left)), True
    return float(base * (0.97 if inj in ("DAY_TO_DAY", "QUESTIONABLE", "DOUBTFUL") else 1.0)), False


def team_value(vals):
    v = sorted(vals, reverse=True)
    return sum(w * x for w, x in zip(DEPTH_W, v))


def _cat_weights(my_z):
    """Balanced G-score weights tilted toward the categories my team is short in (season-long team z), away from those it already owns."""
    tilt = np.array([np.clip(-my_z.get(c, 0.0), -1.5, 1.5) / 1.5 for c in L.CATS])
    return L.BAL * (1 + FIT_TILT * tilt), tilt


def recent_lines(today):
    """Player lines of every finished game in the last BOX_DAYS days (regular season and preseason), with date and preseason flag."""
    import inseason_daily as D
    import inseason_schedule as SCH
    g = SCH.games(include_preseason=True)
    ds = sorted({d.date() for d in g["date"] if today - timedelta(days=BOX_DAYS) <= d.date() <= today})
    frames = []
    for d in ds:
        try:
            raw = D.fetch_day(d)
        except Exception:
            continue
        if raw["lines"]:
            f = pd.DataFrame(raw["lines"])
            f["GAME_DATE"] = d.isoformat()
            f["PRE"] = d < L.SEASON_START
            frames.append(f)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(), D


def box_profiles(today):
    """name-key -> what the last games say: minutes, role, form (Value), luck, the daily model's next-10 projection."""
    df, D = recent_lines(today)
    if df.empty:
        return {}
    logs = D.season_logs(today + timedelta(days=1))
    pr = D.project(df.to_dict("records"), logs)
    pr["GAME_DATE"] = df["GAME_DATE"].to_numpy()
    pr["PRE"] = df["PRE"].to_numpy()
    pr["STARTER"] = df["STARTER"].to_numpy()
    out = {}
    for k, g in pr.groupby("k"):
        g = g.sort_values("GAME_DATE")
        last = g.tail(5)
        mins = last["MIN"].to_numpy()
        ok = last["proj"].notna()
        out[k] = {
            "n": int(len(g)), "n5": int(len(last)), "pre": bool(g["PRE"].all()),
            "min5": round(float(mins.mean()), 1), "min_last": round(float(mins[-1]), 1),
            "min_prev": round(float(mins[:-2].mean()), 1) if len(mins) > 2 else None,
            "min_l2": round(float(mins[-2:].mean()), 1), "starts": int(last["STARTER"].sum()),
            "v5": round(float(last["V"].mean()), 2), "v_last": round(float(last["V"].iloc[-1]), 2), "v_max": round(float(last["V"].max()), 2),
            "luck5": round(float(last["L"].mean()), 2), "neutral5": round(float(last["N"].mean()), 2),
            "proj": round(float(last.loc[ok, "proj"].mean()), 2) if ok.any() else None,
            "dmin": round(float(last["dmin"].mean()), 1),
            "prior_min": round(float(last["prior_min"].mean()), 1) if last["prior_min"].notna().any() else None,
            "has_prior": bool(last["has_prior"].all()),
            "line": {c: round(float(last[c].mean()), 1) for c in ("PTS", "OREB", "DREB", "AST", "STL", "BLK", "FG3M", "TOV", "PF")},
            "fg": f"{int(last['FGM'].sum())}/{int(last['FGA'].sum())}", "ft": f"{int(last['FTM'].sum())}/{int(last['FTA'].sum())}",
            "dates": last["GAME_DATE"].tolist(),
        }
    return out


_SCH = {}


def next_games(team, today, days=7):
    """Dates of `team`'s games in the next `days` days (schedule table is read once per build)."""
    import inseason_schedule as SCH
    start = max(today, L.SEASON_START)
    if _SCH.get("key") != start:
        g = SCH.games()
        g = g[(g["date"].dt.date >= start) & (g["date"].dt.date < start + timedelta(days=days))]
        by = {}
        for t_, d_ in zip(g["team"], g["date"].dt.date):
            by.setdefault(t_, []).append(d_)
        _SCH["key"], _SCH["by"] = start, by
    return _SCH["by"].get(team, [])


def build_fa(me, fa_pl, wk, stream_rows, plan_names, league, today, adds_left):
    """me / fa_pl: engine player dicts (name, team, elig, p, base, ret, inj, r, u, src, own, status, avail_from).
    stream_rows: every add/drop row from streaming() (for the best d_pwin per free agent). plan_names: free agents the streaming planner uses."""
    my_z = next((t["z"] for t in league["teams"] if t["is_me"]), {})
    wts, tilt = _cat_weights(my_z)
    try:
        box = box_profiles(today)
    except Exception as e:
        print("FA box profiles failed:", type(e).__name__, e)
        box = {}
    pre = today < L.SEASON_START

    def prof(p):
        u = p["u"] - U0
        f, hurt = avail_frac(p, today)
        return {"u": u, "val": float((u * L.BAL).sum()), "valf": float((u * wts).sum()), "avail": f, "injured": hurt}

    mine = {p["name"]: prof(p) for p in me}
    for p in me:
        m = mine[p["name"]]
        m["eff"] = m["valf"] * m["avail"] if m["valf"] >= 0 else m["valf"]
    base_team = team_value([m["eff"] for m in mine.values()])
    best_pw = {}
    for r in stream_rows:
        best_pw[r["add"]] = max(best_pw.get(r["add"], -9), r["d_pwin"])
    abs_long = {}
    for team, lst in L.ABSENT.items():
        outs = [y for y in lst if y["inj"] == "OUT" and (y["ret"] is None or (y["ret"] - today).days >= 14)]
        if outs:
            abs_long[team] = outs

    rows = []
    for f in fa_pl:
        k = L.norm(f["name"])
        pf = prof(f)
        eff = pf["valf"] * pf["avail"] if pf["valf"] >= 0 else pf["valf"]
        # best player to drop: the swap that leaves my depth-weighted team value highest
        best = None
        for d in me:
            vals = [mine[q["name"]]["eff"] for q in me if q["name"] != d["name"]] + [eff]
            gain = team_value(vals) - base_team
            if best is None or gain > best[0]:
                best = (gain, d)
        gain, drop = best
        # the gain he would add if healthy (for injured stashes)
        eff_h = pf["valf"] * (f.get("base") or L.P_ACTIVE) if pf["valf"] >= 0 else pf["valf"]
        gain_h = max(team_value([mine[q["name"]]["eff"] for q in me if q["name"] != d["name"]] + [eff_h]) - base_team for d in me) if pf["injured"] else gain
        dd = (pf["u"] - mine[drop["name"]]["u"])
        helps = [L.LABEL[c] for c in sorted(L.CATS, key=lambda c: -dd[L.CATS.index(c)]) if dd[L.CATS.index(c)] >= 0.35][:4]
        hurts = [L.LABEL[c] for c in sorted(L.CATS, key=lambda c: dd[L.CATS.index(c)]) if dd[L.CATS.index(c)] <= -0.35][:3]
        need_help = [L.LABEL[c] for c in L.CATS if tilt[L.CATS.index(c)] >= 0.4 and pf["u"][L.CATS.index(c)] >= 0.35]
        b = box.get(k)
        g7 = next_games(f["team"], today)
        pw = best_pw.get(f["name"])
        rank_in_mine = 1 + sum(1 for m in mine.values() if m["eff"] > eff)
        rec = {"name": f["name"], "team": f["team"], "pos": "/".join(sorted(f["elig"], key=lambda x: ["PG", "SG", "SF", "PF", "C"].index(x) if x in ["PG", "SG", "SF", "PF", "C"] else 9)),
               "own": f.get("own"), "inj": f["inj"], "ret": str(f["ret"]) if f.get("ret") else None,
               "note": (f.get("news") or {}).get("comment"), "status": f.get("status"), "waiver": f.get("avail_from"),
               "val": round(pf["val"], 2), "valf": round(pf["valf"], 2), "avail": round(pf["avail"], 2), "gain": round(gain, 2),
               "gain_h": round(gain_h, 2), "drop": drop["name"], "rank_in_mine": rank_in_mine, "helps": helps, "hurts": hurts,
               "need_help": need_help, "d_pwin": None if pw is None else round(float(pw), 4), "g7": len(g7),
               "g7_days": [d.strftime("%a %d") for d in g7], "src": f["src"], "box": b, "in_plan": f["name"] in plan_names}
        rec["tier"], rec["why"], rec["upgrade"] = classify(rec, pre, adds_left, abs_long.get(f["team"]), today)
        rec["stash"] = rec["tier"] == "WATCH" and rec["inj"] != "ACTIVE" and rec["gain_h"] >= MUST_GAIN
        rec["score"] = _score(rec)
        rows.append(rec)
    return trim(rows, mine, base_team)


def _score(r):
    """Order inside a tier: MUST by team gain, STREAM by this week's win-chance gain, WATCH by how much real evidence (stashes first)."""
    if r["tier"] == "MUST":
        return r["gain"]
    if r["tier"] == "STREAM":
        return (r["d_pwin"] or 0) * 10 + r["g7"] * 0.05 + r["valf"] * 0.05
    if r["tier"] == "WATCH":
        return (3 if r["stash"] else 0) + len(r["why"]) * 0.5 + max(r["gain"], 0) + (0.3 if r["box"] and not r["box"]["pre"] else 0)
    return r["val"]


def trim(rows, mine, base_team):
    keep = {"MUST": 99, "STREAM": 25, "WATCH": 30, "SKIP": 8}
    out = []
    for t, n in keep.items():
        out += sorted([r for r in rows if r["tier"] == t], key=lambda r: -r["score"])[:n]
    near = sorted([r for r in rows if r["inj"] == "ACTIVE" and r["tier"] != "SKIP"], key=lambda r: -r["gain"])[:6]
    mv = sorted(((m["eff"], n) for n, m in mine.items()), reverse=True)
    return {"rows": out, "near": [r["name"] for r in near], "near_rows": [{"name": r["name"], "gain": r["gain"]} for r in near], "n_pool": len(rows),
            "thresholds": {"must_gain": MUST_GAIN, "watch_gain": WATCH_GAIN, "stream_pw": STREAM_PW, "min_avail": MIN_AVAIL},
            "mine": [{"name": n, "eff": round(e, 2)} for e, n in mv]}


def classify(r, pre, adds_left, long_out, today):
    b = r["box"]
    why, up = [], []
    healthy = r["avail"] >= MIN_AVAIL * L.P_ACTIVE
    bx_pre = bool(b and b["pre"])
    # ---- SKIP: a big night / week that the model reads as luck or noise
    if b and b["v_max"] >= 6 and b["proj"] is not None and b["proj"] < 0.5 and r["gain"] < WATCH_GAIN and b["min5"] < 24:
        return "SKIP", [f"best recent Value {b['v_max']:.1f} but the model expects {b['proj']:+.1f} over his next 10 games (luck {b['luck5']:+.1f}, {b['min5']:.0f} min)"], []
    # ---- MUST
    if r["gain"] >= MUST_GAIN and healthy and r["rank_in_mine"] <= 9:
        why.append(f"projects {r['val']:+.1f} Value per game; swapping him for {r['drop']} adds {r['gain']:+.2f} to your depth-weighted team value")
        if r["helps"]:
            why.append("adds " + ", ".join(r["helps"]) + (" (you are short in " + ", ".join(r["need_help"]) + ")" if r["need_help"] else ""))
        if r["hurts"]:
            why.append("costs " + ", ".join(r["hurts"]) + " versus " + r["drop"])
        if b and b["proj"] is not None and b["proj"] < r["val"] - 2.5 and not bx_pre:
            return "WATCH", why + [f"but his recent games project only {b['proj']:+.1f}: the role looks smaller than the preseason model assumed"], ["plays 24+ minutes again"]
        if b and not bx_pre and b["min5"] < 12 and b["n5"] >= 3:
            return "WATCH", why + [f"averages only {b['min5']:.0f} minutes lately"], ["back to 20+ minutes"]
        return "MUST", why, []
    # ---- STREAM: this week's win chance, or a good schedule
    stream_ok = adds_left > 0 and r["inj"] in ("ACTIVE", "DAY_TO_DAY") and healthy
    if stream_ok and (r["d_pwin"] or 0) >= STREAM_PW:
        why.append(f"best swap raises this week's win chance by {r['d_pwin'] * 100:.1f} pts")
        if r["in_plan"]:
            why.append("used by the day-by-day streaming plan")
        if r["helps"]:
            why.append("helps " + ", ".join(r["helps"]))
        return "STREAM", why, []
    if stream_ok and r["g7"] >= 3 and r["valf"] >= -0.5 and r["gain"] >= -0.05:
        why.append(f"{r['g7']} games in the next 7 days ({', '.join(r['g7_days'])})")
        if r["need_help"]:
            why.append("fits what you are short in: " + ", ".join(r["need_help"]))
        elif r["helps"]:
            why.append("helps " + ", ".join(r["helps"]))
        return "STREAM", why, []
    # ---- WATCH
    sig = []
    if b and b["n5"] >= 2 and b["dmin"] >= 5 and b["min5"] >= ROLE_MIN and r["valf"] >= -2.6:
        sig.append(f"minutes up: {b['min5']:.0f} per game vs usual {b['prior_min']:.0f}" if b["prior_min"] else f"{b['min5']:.0f} minutes per game")
        up.append("keeps 22+ minutes over the next 3 games (a role that holds is worth +0.05 Value per minute)")
    if b and b["min_prev"] is not None and b["min_l2"] - b["min_prev"] >= 6 and b["min_l2"] >= ROLE_MIN and r["valf"] >= -2.6:
        sig.append(f"last two games {b['min_l2']:.0f} min vs {b['min_prev']:.0f} before")
        up.append("minutes stay up in the next 2 games")
    if b and b["proj"] is not None and b["proj"] >= 1.0 and b["luck5"] < 1.5 and r["gain"] >= WATCH_GAIN:
        sig.append(f"recent games project {b['proj']:+.1f} over the next 10 (not luck: shooting luck {b['luck5']:+.1f})")
        up.append("a few more games like this; the projection updates every refresh")
    if long_out and r["inj"] == "ACTIVE" and r["valf"] >= -1.8 and (not b or b["min5"] < 26) and r["gain"] >= -0.15:
        names = ", ".join(y["name"] for y in long_out[:2])
        sig.append(f"{names} out for a long time, so his team has minutes to give")
        up.append("he starts getting 22+ minutes")
    if r["gain"] >= WATCH_GAIN and not (r["gain"] >= MUST_GAIN):
        sig.append(f"close: team value {r['gain']:+.2f} vs {MUST_GAIN:.2f} needed for a must")
        up.append("a hot week or an injury on your roster would push him over")
    if r["inj"] not in ("ACTIVE",) and r["gain_h"] >= MUST_GAIN:
        when = f"back {r['ret']}" if r["ret"] else "no return date"
        sig.append(f"a must when healthy (+{r['gain_h']:.2f}); {r['inj'].replace('_', ' ').lower()}, {when}")
        up.append("a return date within two weeks, or he is activated")
    if sig:
        if pre and bx_pre:
            sig.append("based on preseason games: minutes and rotations are not reliable yet")
        return "WATCH", sig, up[:2]
    return "", [], []
