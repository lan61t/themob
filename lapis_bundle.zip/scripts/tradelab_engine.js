// Trade lab engine: browser port of inseason_live.team_pack / aggregate / evaluate and inseason_trade scoring.
// Input `LB` = state.trades.lab (exported by inseason_tradelab.Lab.export_lite). Pure functions, no DOM.
// This block is inlined into lapis_app_template.html between the TL-ENGINE markers and tested with node against the Python engine.
const TL=(function(){
  const norm=s=>String(s).toLowerCase().replace(/[^a-z0-9]/g,'');
  const cdf=x=>{const z=x/Math.SQRT2,a=Math.abs(z),t=1/(1+0.3275911*a);
    const poly=t*(0.254829592+t*(-0.284496736+t*(1.421413741+t*(-1.453152027+t*1.061405429))));
    return 0.5*(1+Math.sign(z)*(1-poly*Math.exp(-a*a)))};
  const slotFits=(LB,slot,elig)=>LB.slot_ok[slot].some(p=>elig.includes(p));
  function canFill(LB,el){
    const S=LB.slots.length;if(el.length>S)return false;
    const match=Array(S).fill(-1);
    const aug=(i,seen)=>{for(let s=0;s<S;s++){if(seen.has(s)||!slotFits(LB,LB.slots[s],el[i]))continue;seen.add(s);
      if(match[s]===-1||aug(match[s],seen)){match[s]=i;return true}}return false};
    for(let i=0;i<el.length;i++)if(!aug(i,new Set()))return false;
    return true}
  function greedy(LB,items,elig,nDays,cap,floor){
    const chosen=[],perDay=Array.from({length:nDays},()=>[]);let used=0;
    const sorted=items.map((it,i)=>[it,i]).sort((a,b)=>(b[0][0]*b[0][1]-a[0][0]*a[0][1])||(a[1]-b[1])).map(x=>x[0]);
    for(const [v,p,name,d] of sorted){
      if(v*p<=floor)break;
      if(cap!==null&&used+p>cap+1e-9)continue;
      if(!canFill(LB,perDay[d].map(n=>elig[n]).concat([elig[name]])))continue;
      perDay[d].push(name);chosen.push([name,d,v,p]);used+=p}
    return chosen}
  // one week for one roster (list of names) -> expected totals (14) and variance (13)
  function weekTotals(LB,names,wi){
    const wk=LB.weeks[wi],sun=wk.sun==null?-1:wk.sun,elig={};
    const items=[];
    for(const n of names){const P=LB.players[n];if(!P)continue;elig[n]=P.elig;
      for(let d=0;d<wk.n;d++){const p=P.p[wi][d];if(!(p>0))continue;
        const m=P.am[wi][d];const v=m>0.01?P.val*(1+LB.kappa*m):P.val;items.push([v,p,n,d])}}
    const cap=wk.cap,sunCap=LB.sun_cap||0;
    const ms=items.filter(it=>it[3]!==sun),su=items.filter(it=>it[3]===sun);
    const aMs=greedy(LB,ms,elig,wk.n,cap-LB.buffer,0);
    const aSun=sunCap?greedy(LB,su,elig,wk.n,null,0).slice(0,sunCap):[];
    let best=aMs.concat(aSun);
    const bMs=greedy(LB,ms,elig,wk.n,null,0);
    const sumP=a=>a.reduce((s,x)=>s+x[3],0),sumVP=a=>a.reduce((s,x)=>s+x[2]*x[3],0);
    if(sumP(bMs)>cap&&sumVP(bMs)>sumVP(best))best=bMs;
    const tot=new Array(14).fill(0),vr=new Array(13).fill(0),CI={};LB.comp.forEach((c,i)=>CI[c]=i);
    for(const [name,d,,p] of best){
      const P=LB.players[name],m=P.am[wi][d];
      const r=P.r.map((x,i)=>m>0.01?x*(1+LB.abs_k[i]*m):x);
      for(let i=0;i<14;i++)tot[i]+=p*r[i];
      LB.cats.forEach((c,i)=>{let x;
        if(LB.pct[c]){const [made,att]=LB.pct[c];x=r[CI[made]]-LB.comp_q[c]*r[CI[att]]}else x=r[CI[c]];
        vr[i]+=p*LB.tau[i]**2*LB.g_avg*LB.sd[i]**2+p*(1-p)*x*x})}
    return {tot,vr}}
  // mean over the weeks, like inseason_trade._tv
  function teamTV(LB,names){
    const W=LB.weeks.length,tot=new Array(14).fill(0),vr=new Array(13).fill(0);
    for(let w=0;w<W;w++){const a=weekTotals(LB,names,w);a.tot.forEach((x,i)=>tot[i]+=x/W);a.vr.forEach((x,i)=>vr[i]+=x/W)}
    return {tot,vr}}
  function evaluate(LB,A,B){          // -> {pc[13], pw}
    const CI={};LB.comp.forEach((c,i)=>CI[c]=i);const pc=[];
    LB.cats.forEach((c,i)=>{let mean,sd;
      if(LB.pct[c]){const [made,att]=LB.pct[c];const aM=Math.max(A.tot[CI[att]],1e-9),aO=Math.max(B.tot[CI[att]],1e-9);
        mean=A.tot[CI[made]]/aM-B.tot[CI[made]]/aO;sd=Math.sqrt(A.vr[i]/aM**2+B.vr[i]/aO**2)}
      else{mean=A.tot[CI[c]]-B.tot[CI[c]];sd=Math.sqrt(A.vr[i]+B.vr[i])}
      if(LB.lower.includes(c))mean=-mean;
      pc.push(sd>1e-9?cdf(mean/sd):(mean>1e-9?1:(mean<-1e-9?0:0.5)))});
    let dp=new Array(14).fill(0);dp[0]=1;
    for(const p of pc){const nx=dp.map(x=>x*(1-p));for(let k=1;k<14;k++)nx[k]+=dp[k-1]*p;dp=nx}
    return {pc,pw:dp.slice(7).reduce((s,x)=>s+x,0)}}
  const teamStat=(LB,id)=>({tot:LB.teams[id].tot,vr:LB.teams[id].var});
  function power(LB,stats,a){const ids=Object.keys(stats).filter(b=>b!==a);
    return ids.reduce((s,b)=>s+evaluate(LB,stats[a],stats[b]).pw,0)/ids.length}
  function catWin(LB,stats,a){const ids=Object.keys(stats).filter(b=>b!==a),out=new Array(13).fill(0);
    for(const b of ids){evaluate(LB,stats[a],stats[b]).pc.forEach((p,i)=>out[i]+=p/ids.length)}return out}
  function zcat(LB,tot){const CI={};LB.comp.forEach((c,i)=>CI[c]=i);
    return LB.cats.map(c=>{let v;if(LB.pct[c]){const [m,a]=LB.pct[c];v=tot[CI[a]]>0?tot[CI[m]]/tot[CI[a]]:0}else v=tot[CI[c]];
      return ((v-LB.avg_cat.mean[c])/LB.avg_cat.sd[c])*(LB.lower.includes(c)?-1:1)})}
  // value of a player to a team (inseason_trade._eff): tilted G-score weights, scaled by availability when positive
  function weights(LB,teamId){const z=LB.teams[teamId].z;
    return LB.cats.map((c,i)=>{const tilt=Math.max(-1.5,Math.min(1.5,-(z[c]||0)))/1.5;return LB.bal[i]*(1+LB.fit_tilt*tilt)})}
  function eff(LB,name,w){const P=LB.players[name];let v=0;for(let i=0;i<13;i++)v+=(P.u[i]-LB.u0[i])*w[i];return v>=0?v*P.avail:v}
  function settle(LB,names,size,received,w){
    const pl=names.slice(),recv=new Set(received),added=[];
    while(pl.length>size){
      let cand=pl.filter(n=>!recv.has(n)&&!LB.keep.includes(norm(n)));
      if(!cand.length)cand=pl.filter(n=>!recv.has(n));if(!cand.length)cand=pl;
      let worst=cand[0];for(const n of cand)if(eff(LB,n,w)<eff(LB,worst,w))worst=n;
      pl.splice(pl.indexOf(worst),1)}
    for(const f of LB.fill){if(pl.length>=size)break;if(!pl.includes(f)){pl.push(f);added.push(f)}}
    return {pl,added}}
  function verdict(dMe,dTh){return dMe>=0.004&&dTh>=0.002?'WIN-WIN':dMe>=0.004&&dTh>=-0.002?'FAIR':dMe>=0.004?'ONE-SIDED':(dMe>=-0.002&&dTh>=0.002?'FAVOURS THEM':'NO')}
  // full trade: me gives `give`, partner `pid` gives `get` (names). Returns the same fields as the server's Lab.scenario.
  function analyze(LB,pid,give,get){
    const me=LB.me,mine=LB.teams[me].players,theirs=LB.teams[pid].players;
    const gset=new Set(give),tset=new Set(get);
    const bad=give.filter(n=>!mine.includes(n)).concat(get.filter(n=>!theirs.includes(n)));
    if(bad.length||!give.length||!get.length)throw new Error('Not on the right roster: '+(bad.join(', ')||'pick at least one player on each side'));
    const wm=weights(LB,me),wp=weights(LB,pid);
    const newMe0=mine.filter(n=>!gset.has(n)).concat(get),newTh0=theirs.filter(n=>!tset.has(n)).concat(give);
    const sm=settle(LB,newMe0,LB.teams[me].size,get,wm),st=settle(LB,newTh0,LB.teams[pid].size,give,wp);
    // baseline of both teams is rebuilt here as well, so a small difference between this port and the Python engine cancels
    const b1=teamTV(LB,mine),b2=teamTV(LB,theirs),a1=teamTV(LB,sm.pl),a2=teamTV(LB,st.pl);
    const base={},aft={};for(const id of Object.keys(LB.teams)){base[id]=teamStat(LB,id);aft[id]=teamStat(LB,id)}
    base[me]=b1;base[pid]=b2;aft[me]=a1;aft[pid]=a2;
    const pm0=power(LB,base,me),pm1=power(LB,aft,me),pt0=power(LB,base,pid),pt1=power(LB,aft,pid);
    const cm0=catWin(LB,base,me),cm1=catWin(LB,aft,me),ct0=catWin(LB,base,pid),ct1=catWin(LB,aft,pid);
    const zb={},za={};
    const zrows=(zb_,za_,c0,c1)=>LB.cats.map((c,i)=>({cat:LB.labels[i],z0:zb_[i],z1:za_[i],dz:za_[i]-zb_[i],p0:c0[i],p1:c1[i]}));
    const rm=zrows(zcat(LB,b1.tot),zcat(LB,a1.tot),cm0,cm1),rt=zrows(zcat(LB,b2.tot),zcat(LB,a2.tot),ct0,ct1);
    const dMe=pm1-pm0,dTh=pt1-pt0;
    const info=(n,w)=>{const P=LB.players[n];return {name:n,team:P.team,elig:P.elig,inj:P.inj,pg:Object.fromEntries(LB.comp.map((c,i)=>[c,P.r[i]])),
      avail:P.avail,eff:eff(LB,n,w),games:P.p.reduce((s,wk)=>s+wk.filter(x=>x>0).length,0),exp_games:P.p.reduce((s,wk)=>s+wk.reduce((a,b)=>a+b,0),0)}};
    const top=r=>r.slice().sort((x,y)=>Math.abs(y.dz)-Math.abs(x.dz)).filter(x=>Math.abs(x.dz)>=0.2).slice(0,5).map(x=>({cat:x.cat,dz:x.dz}));
    return {partner_id:pid,partner:LB.teams[pid].name,owner:LB.teams[pid].owner,give,get,kind:give.length+'-for-'+get.length,
      fill_me:sm.added,fill_them:st.added,
      drop_me:mine.filter(n=>!gset.has(n)&&!sm.pl.includes(n)),drop_them:theirs.filter(n=>!tset.has(n)&&!st.pl.includes(n)),
      me_from:pm0,me_to:pm1,them_from:pt0,them_to:pt1,d_me:dMe,d_them:dTh,me_cat:rm,them_cat:rt,me_cats:top(rm),them_cats:top(rt),
      give_info:give.map(n=>info(n,wm)),get_info:get.map(n=>info(n,wm)),verdict:verdict(dMe,dTh),weeks:LB.weeks.map(w=>w.mp),lite:true}}
  const tv=(LB,vals)=>vals.slice().sort((a,b)=>b-a).reduce((s,x,i)=>s+(LB.depth[i]||0)*x,0);
  const combos=(arr,k)=>{const out=[];const rec=(st,cur)=>{if(cur.length===k){out.push(cur.slice());return}for(let i=st;i<arr.length;i++){cur.push(arr[i]);rec(i+1,cur);cur.pop()}};rec(0,[]);return out};
  // best partners for the players I want to send (same screen as the Python Lab.search, then a full check of the top few per partner)
  function search(LB,giveNames,perPartner,top,onProgress,kind){
    const ngW=kind?+kind[0]:0,ntW=kind?+kind[2]:0;
    perPartner=perPartner||2;top=top||12;
    const me=LB.me,mine=LB.teams[me].players;
    if(!giveNames.length||giveNames.length>2||giveNames.some(n=>!mine.includes(n)))throw new Error('Choose 1 or 2 of your own players to send');
    const wm=weights(LB,me),em={};mine.forEach(n=>em[n]=eff(LB,n,wm));
    const bMe=tv(LB,mine.map(n=>em[n])),res=[];
    const partners=Object.keys(LB.teams).filter(id=>id!==me);
    let k=0;
    for(const pid of partners){
      const theirs=LB.teams[pid].players,wp=weights(LB,pid),ep={};theirs.forEach(n=>ep[n]=eff(LB,n,wp));
      const emAll=Object.assign({},em),epAll=Object.assign({},ep);theirs.forEach(n=>emAll[n]=eff(LB,n,wm));mine.forEach(n=>epAll[n]=eff(LB,n,wp));
      const bTh=tv(LB,theirs.map(n=>ep[n]));
      const gives=[giveNames.slice()];
      if(giveNames.length===1)mine.forEach(q=>{if(q!==giveNames[0])gives.push([giveNames[0],q])});
      if(ngW)for(let i=gives.length-1;i>=0;i--)if(gives[i].length!==ngW)gives.splice(i,1);
      const cands=[];
      for(const give of gives)for(const nt of (ntW?[ntW]:[1,2])){
        if(!ntW&&give.length===2&&nt===2&&giveNames.length===1)continue;
        for(const get of combos(theirs,nt)){
          const gs=new Set(give),ts=new Set(get);
          const nm=mine.filter(n=>!gs.has(n)).concat(get),nth=theirs.filter(n=>!ts.has(n)).concat(give);
          const vMe=nm.map(n=>emAll[n]).sort((a,b)=>b-a).slice(0,mine.length),vTh=nth.map(n=>epAll[n]).sort((a,b)=>b-a).slice(0,theirs.length);
          const dMe=tv(LB,vMe)-bMe,dTh=tv(LB,vTh)-bTh;
          if(dMe>0&&dTh>-0.6)cands.push([dMe+1.5*Math.min(dTh,0.3),give,get])}}
      cands.sort((a,b)=>b[0]-a[0]);
      for(const [,give,get] of cands.slice(0,perPartner)){try{res.push(analyze(LB,pid,give,get))}catch(e){}}
      if(onProgress)onProgress(++k,partners.length)}
    const rank={'WIN-WIN':0,'FAIR':1,'ONE-SIDED':2},list=res.filter(r=>r.verdict in rank).sort((a,b)=>rank[a.verdict]-rank[b.verdict]||b.d_me-a.d_me);
    const keep=[],per={};
    for(const r of list){if((per[r.partner_id]||0)<2){keep.push(r);per[r.partner_id]=(per[r.partner_id]||0)+1}if(keep.length>=top)break}
    return keep}
  return {analyze,search,teamTV,power,evaluate,weights,eff,norm,verdict};
})();
