"""'How far can this number move?': the swing band shown under the win chance (Lapis, T27A and Julid share this file).

Why it exists (week 1, 2026): a 73% start fell to 44% after three days with nothing wrong in the engine. The pre-week numbers ARE calibrated
(backtests below), but a 5-in-6 favourite still drops under 50% by midweek in a real share of weeks. The page should say so.

Model (one assumption, stated on the page): the rest of the week is one latent score X ~ N(mu, 1) with P(win) = P(X > 0) = p_now. By a checkpoint
`h` days ahead a share f of that uncertainty has resolved, f = the player-games both sides play in those days / all player-games still to come.
Then  p_h = Phi((mu + z * sqrt(f)) / sqrt(1 - f))  with z ~ N(0, 1),  so
    q-th quantile of p_h = Phi((mu + z_q sqrt(f)) / sqrt(1 - f)),     P(p_h < 0.5) = Phi(-mu / sqrt(f)).
It is a martingale (the average of p_h is p_now). It does not model injuries or streaming moves, which add movement on top.

Pre-week reliability (raw engine, random pairings, 4 seasons): winprob_backtest.json (Lapis/T27A, 13 cats, 7,140 matchups) and
winprob_backtest_9cat.json (Julid, 9 cats, 6,120 matchups). Stored here as constants so the cloud build needs no extra file.
"""
from statistics import NormalDist

N = NormalDist()

# bin -> (n, predicted, actual)
RELIABILITY = {
    13: [(204, .062, .108), (476, .159, .171), (818, .251, .270), (1011, .351, .335), (1106, .448, .454),
         (1118, .550, .526), (929, .650, .651), (810, .748, .706), (481, .847, .837), (187, .936, .920)],
    9: [(235, .060, .085), (450, .154, .160), (663, .253, .277), (771, .352, .376), (923, .451, .459),
        (898, .549, .546), (793, .648, .656), (687, .747, .729), (495, .845, .836), (205, .936, .924)],
}
N_MATCHUPS = {13: 7140, 9: 6120}


def reliability(p, n_cats):
    """Backtest line for the 10-point band that contains p: how often such pre-week forecasts won."""
    i = min(9, max(0, int(p * 10)))
    n, pred, act = RELIABILITY[n_cats][i]
    return {"band": f"{i * 10}-{i * 10 + 10}%", "n": n, "won": act, "said": pred, "total": N_MATCHUPS[n_cats]}


def band(p_now, path, n_cats, horizon=3):
    """Swing band for the checkpoint `horizon` days ahead (fewer if the week is shorter). `path` = the state's per-day list with
    gp_me / gp_op (cumulative player-games) and gp_me_before / gp_op_before. Returns None when the week is (nearly) over."""
    if not path or len(path) < 2 or p_now is None:
        return None
    p = min(max(float(p_now), 0.005), 0.995)
    h = min(horizon, len(path) - 1)
    g0 = path[0]["gp_me_before"] + path[0]["gp_op_before"]
    tot = path[-1]["gp_me"] + path[-1]["gp_op"] - g0
    part = path[h - 1]["gp_me"] + path[h - 1]["gp_op"] - g0
    if tot <= 1e-6 or part <= 1e-6:
        return None
    f = min(0.98, max(0.02, part / tot))
    mu = N.inv_cdf(p)
    q = lambda z: N.cdf((mu + z * f ** 0.5) / (1 - f) ** 0.5)
    z90 = N.inv_cdf(0.9)
    lo, hi = q(-z90), q(z90)
    return {"h": h, "label": path[h - 1]["label"], "f": f, "p_now": p, "lo": lo, "hi": hi,
            "p_under": float(N.cdf(-mu / f ** 0.5)) if p >= 0.5 else float(N.cdf(mu / f ** 0.5)),   # chance the side flips (fav -> underdog, or underdog -> fav)
            "side": "under" if p >= 0.5 else "over", "rel": reliability(p, n_cats)}
