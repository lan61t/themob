"""Trade finder for the Lapis league: for every other team, the 1-for-1, 2-for-1 and 1-for-2 trades that raise MY power and do not lower THEIRS
(a trade they should accept; ESPN needs 8 veto votes to block, so lopsided deals tend to die in review anyway).

Two stages:
  1. cheap screen: depth-weighted team value of both rosters with each side's own category tilt (the same scale as the free-agent list),
     every swap of up to 2 players, keep the best few per partner;
  2. exact check: rebuild both teams over the next N weeks of real schedule with the matchup engine (starts, positions, injuries, cap)
     and compare power = average chance of beating each other team in a week, plus each team's category ranks before and after.
After a trade a roster that is short is filled with the best free agent and one that is long drops its weakest player, so 2-for-1 and
1-for-2 deals are judged on the roster you would really have.
Limits: the model that rated the rosters is the same one that judges the trade (it likes its own picks); a trade is a suggestion to
negotiate, not a promise the other manager agrees; injured players are valued by their expected games.
"""
import sys
from datetime import datetime, timedelta
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402

N_WEEKS = 4
SCREEN_PER_PARTNER = 6
MAX_ROWS = 14
MIN_THEM = -0.002           # their power may not fall by more than 0.2 points
MIN_ME = 0.004              # my power must rise at least 0.4 points


def _weeks(today, mp):
    out = []
    for m in range(mp, min(24, mp + N_WEEKS - 1) + 1):
        start = L.period_bounds(m)[0]
        out.append(L.Week(m, datetime(2000, 1, 1), start - timedelta(days=1), real_today=today))
    return out


def _tv(players, wks):
    ts, vs = [], []
    for wk in wks:
        a, v = L.aggregate(L.team_pack(players, wk, None, L.BAL))
        ts.append(a)
        vs.append(v)
    return np.mean(ts, axis=0), np.mean(vs, axis=0)


def _power(a, tot, var):
    return float(np.mean([L.evaluate(tot[a], var[a], tot[b], var[b])[1] for b in tot if b != a]))


def _eff(p, wts, today):
    u = p["u"] - FA.U0
    f, _ = FA.avail_frac(p, today)
    v = float((u * wts).sum())
    return v * f if v >= 0 else v


def _settle(players, size, fill, drop_pool_names, effs):
    """Bring a roster to `size`: drop the weakest (never one just received), or add the best free agents."""
    pl = list(players)
    while len(pl) > size:
        cand = [p for p in pl if p["name"] not in drop_pool_names] or pl
        w = min(cand, key=lambda p: effs[p["name"]])
        pl.remove(w)
    added = []
    for f in fill:
        if len(pl) >= size:
            break
        if all(f["name"] != p["name"] for p in pl):
            pl.append(f)
            added.append(f["name"])
    return pl, added


def find_trades(E, proj, today, mp, my_id, league, fa_pl, wts_for=None, screen_per=SCREEN_PER_PARTNER, finalize=True, relax=False):
    """league: the `league` block (teams with z, rank, power). fa_pl: engine free agents (used to fill a short roster)."""
    wks = _weeks(today, mp)
    z_by = {t["id"]: t["z"] for t in league["teams"]}
    rosters = {}
    from inseason_league import _players
    for tid, t in E["teams"].items():
        rosters[tid] = _players(t["roster"], proj)
    ids = list(rosters)
    base = {tid: _tv(rosters[tid], wks) for tid in ids}
    tot = {tid: base[tid][0] for tid in ids}
    var = {tid: base[tid][1] for tid in ids}
    pw0 = {tid: _power(tid, tot, var) for tid in ids}
    vals0 = {tid: L.cat_values(tot[tid]) for tid in ids}
    cm = {c: np.mean([vals0[t][c] for t in ids]) for c in L.CATS}
    cs = {c: (np.std([vals0[t][c] for t in ids]) or 1.0) for c in L.CATS}

    def zcat(v):
        return {c: ((v[c] - cm[c]) / cs[c]) * (-1 if c in L.LOWER_BETTER else 1) for c in L.CATS}

    z0 = {tid: zcat(vals0[tid]) for tid in ids}
    size = {tid: len(rosters[tid]) for tid in ids}
    fill_sorted = sorted([f for f in fa_pl if str(f.get("inj") or "ACTIVE").upper() in ("ACTIVE", "DAY_TO_DAY")],
                         key=lambda f: -_eff(f, L.BAL, today))      # fill a short roster with a healthy free agent (not a long-term stash)
    out, screened = [], 0
    for pid in ids:
        if pid == my_id:
            continue
        wm, _ = FA._cat_weights(z_by[my_id])
        wp, _ = FA._cat_weights(z_by[pid])
        em = {p["name"]: _eff(p, wm, today) for p in rosters[my_id]}                 # value to ME of everyone on both rosters
        ep = {p["name"]: _eff(p, wp, today) for p in rosters[pid]}
        em_all = {**em, **{p["name"]: _eff(p, wm, today) for p in rosters[pid]}}
        ep_all = {**ep, **{p["name"]: _eff(p, wp, today) for p in rosters[my_id]}}
        mine, theirs = rosters[my_id], rosters[pid]
        b_me = FA.team_value([em[p["name"]] for p in mine])
        b_th = FA.team_value([ep[p["name"]] for p in theirs])
        cands = []
        for ng in (1, 2):
            for nt in (1, 2):
                if ng == 2 and nt == 2:
                    continue
                for give in combinations(mine, ng):
                    for get in combinations(theirs, nt):
                        g_names, t_names = {p["name"] for p in give}, {p["name"] for p in get}
                        new_me = [p for p in mine if p["name"] not in g_names] + list(get)
                        new_th = [p for p in theirs if p["name"] not in t_names] + list(give)
                        v_me = sorted([em_all[p["name"]] for p in new_me], reverse=True)[:size[my_id]]
                        v_th = sorted([ep_all[p["name"]] for p in new_th], reverse=True)[:size[pid]]
                        d_me, d_th = FA.team_value(v_me) - b_me, FA.team_value(v_th) - b_th
                        if d_me > 0.05 and d_th > (-0.6 if relax else -0.15):
                            cands.append((d_me + 1.5 * min(d_th, 0.3), give, get, d_me, d_th))
        cands.sort(key=lambda x: -x[0])
        picked, seen = [], set()
        for sc, give, get, d_me, d_th in cands:             # screen: best few per partner, never the same pair of sides twice
            key = (frozenset(p["name"] for p in give), frozenset(p["name"] for p in get))
            if key in seen:
                continue
            seen.add(key)
            picked.append((give, get, d_me, d_th))
            if len(picked) >= screen_per:
                break
        screened += len(cands)
        for give, get, d_me, d_th in picked:
            g_names, t_names = {p["name"] for p in give}, {p["name"] for p in get}
            new_me = [p for p in mine if p["name"] not in g_names] + list(get)
            new_th = [p for p in theirs if p["name"] not in t_names] + list(give)
            effs_me = {p["name"]: em_all[p["name"]] for p in new_me}
            effs_th = {p["name"]: ep_all[p["name"]] for p in new_th}
            new_me, add_me = _settle(new_me, size[my_id], fill_sorted, t_names, effs_me)
            new_th, add_th = _settle(new_th, size[pid], fill_sorted, g_names, effs_th)
            dropped_me = [p["name"] for p in mine if p["name"] not in g_names and p["name"] not in {q["name"] for q in new_me}]
            dropped_th = [p["name"] for p in theirs if p["name"] not in t_names and p["name"] not in {q["name"] for q in new_th}]
            a1, v1 = _tv(new_me, wks)
            a2, v2 = _tv(new_th, wks)
            tot2, var2 = dict(tot), dict(var)
            tot2[my_id], var2[my_id], tot2[pid], var2[pid] = a1, v1, a2, v2
            pm, pt = _power(my_id, tot2, var2), _power(pid, tot2, var2)
            zm, zt = zcat(L.cat_values(a1)), zcat(L.cat_values(a2))
            cm_ch = [(L.LABEL[c], zm[c] - z0[my_id][c]) for c in L.CATS if abs(zm[c] - z0[my_id][c]) >= 0.2]
            ct_ch = [(L.LABEL[c], zt[c] - z0[pid][c]) for c in L.CATS if abs(zt[c] - z0[pid][c]) >= 0.2]
            out.append({"partner_id": pid, "partner": E["teams"][pid]["name"], "owner": E["teams"][pid]["owner"],
                        "give": [p["name"] for p in give], "get": [p["name"] for p in get], "kind": f"{len(give)}-for-{len(get)}",
                        "fill_me": add_me, "drop_me": dropped_me, "fill_them": add_th, "drop_them": dropped_th,
                        "me_from": pw0[my_id], "me_to": pm, "them_from": pw0[pid], "them_to": pt,
                        "d_me": pm - pw0[my_id], "d_them": pt - pw0[pid],
                        "me_cats": [{"cat": c, "dz": float(d)} for c, d in sorted(cm_ch, key=lambda x: -abs(x[1]))[:5]],
                        "them_cats": [{"cat": c, "dz": float(d)} for c, d in sorted(ct_ch, key=lambda x: -abs(x[1]))[:5]],
                        "proxy_me": float(d_me), "proxy_them": float(d_th)})
    for r in out:
        r["verdict"] = ("WIN-WIN" if r["d_me"] >= MIN_ME and r["d_them"] >= 0.002 else
                        "FAIR" if r["d_me"] >= MIN_ME and r["d_them"] >= MIN_THEM else
                        "ONE-SIDED" if r["d_me"] >= MIN_ME else "NO")
    if not finalize:
        return out
    good = [r for r in out if r["verdict"] != "NO"]
    rank = {"WIN-WIN": 0, "FAIR": 1, "ONE-SIDED": 2}
    good.sort(key=lambda r: (rank[r["verdict"]], -r["d_me"]))
    rows, per = [], {}
    for r in good:                                          # at most 2 per partner so one team does not fill the page
        if per.get(r["partner_id"], 0) < 2:
            rows.append(r)
            per[r["partner_id"]] = per.get(r["partner_id"], 0) + 1
        if len(rows) >= MAX_ROWS:
            break
    return {"rows": rows, "screened": screened, "checked": len(out), "weeks": [w.mp for w in wks],
            "my_power": pw0[my_id], "rule": {"min_me": MIN_ME, "min_them": MIN_THEM}}


def partner_trades(E, proj, today, mp, my_id, league, fa_pl, per=8):
    """Best trades for EACH single partner, so the page can show 'only this team'. Looks deeper than find_trades (10 screened per partner,
    looser screen on what the partner gives up) and keeps every verdict, ranked WIN-WIN > FAIR > ONE-SIDED, then by my power gain.
    A partner with nothing that raises my power gets an empty list (the page says so)."""
    out = find_trades(E, proj, today, mp, my_id, league, fa_pl, screen_per=10, finalize=False, relax=True)
    rank = {"WIN-WIN": 0, "FAIR": 1, "ONE-SIDED": 2, "NO": 3}
    by = {}
    for r in out:
        by.setdefault(str(r["partner_id"]), []).append(r)
    res = {}
    for pid, rows in by.items():
        rows.sort(key=lambda r: (rank[r["verdict"]], -r["d_me"]))
        keep = [r for r in rows if r["verdict"] != "NO"][:per]
        res[pid] = {"rows": keep, "checked": len(rows)}
    return res
