"""Player rater and roster analysis for the Lapis league.

rater(): ESPN's own Player Rater (per-category ratings from the fantasy API, view mStatRatings) next to OUR rating of the same players, and the
difference. Ours = the engine's per-game projection (preseason model blended with real games) expressed as 13 category z-scores, then each
category is centred on ESPN's average and all are stretched by one common factor so the total has ESPN's spread, over the same players (ESPN rank <= 250 that we can project), so the two are on one
scale and 'Diff' = our total minus ESPN's total in ESPN rating points (positive = we like him more). Without that step the raw scales differ
(ESPN centres on its own pool). Players we cannot project (no history, no games) show ESPN's numbers only.
Rank diff = ESPN rank minus our rank, both counted among the same projected players (positive = we rank him higher).

rosters(): every team's players with projected per-game stats, our category ratings, and ESPN's, for the Rosters tab.
Limit: ESPN's numbers are its season rating (preseason: its projection); ours blends our projection with real games, so early differences are
mostly projection disagreements, not luck.
"""
import json
import sys
from pathlib import Path

import numpy as np
from espn_api.basketball.constant import PRO_TEAM_MAP

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402

SID = {0: "pts", 1: "blk", 2: "stl", 3: "ast", 4: "oreb", 5: "dreb", 9: "pf", 11: "to", 15: "ftm", 17: "3pm", 19: "fg_pct", 20: "ft_pct", 21: "3p_pct"}
LIMIT = 700
FIT_TOP = 250


def fetch_ratings(lg):
    filt = {"players": {"filterStatus": {"value": ["FREEAGENT", "WAIVERS", "ONTEAM"]}, "filterSlotIds": {"value": list(range(0, 15))},
                        "limit": LIMIT, "sortPercOwned": {"sortPriority": 1, "sortAsc": False}}}
    d = lg.espn_request.league_get(params={"view": ["kona_player_info", "mStatRatings"]}, headers={"x-fantasy-filter": json.dumps(filt)})
    return d["players"]


def _pg(r):
    """Per-game projection in the league's 13 categories (same keys as L.CATS)."""
    g = lambda c: float(r[L.CI[c]])
    return {"pts": g("pts"), "stl": g("stl"), "blk": g("blk"), "oreb": g("oreb"), "dreb": g("dreb"), "fg_pct": g("fgm") / max(g("fga"), 1e-9),
            "3pm": g("3pm"), "3p_pct": g("3pm") / max(g("3pa"), 1e-9), "ftm": g("ftm"), "ft_pct": g("ftm") / max(g("fta"), 1e-9),
            "to": g("to"), "pf": g("pf"), "ast": g("ast")}


def build(E, proj):
    raw = fetch_ratings(E["lg"])
    team_name = {tid: t["name"] for tid, t in E["teams"].items()}
    rows = []
    for x in raw:
        r = (x.get("ratings") or {}).get("0")
        pl = x["player"]
        if not r:
            continue
        e = {SID[s["forStat"]]: float(s["rating"]) for s in r["statRankings"] if s["forStat"] in SID}
        if len(e) < 13:
            continue
        name = pl["fullName"]
        pr = proj.get(L.norm(name)) or L.fallback_projection(name)
        u = (L.sigma_units(pr["r"]) - FA.U0) if pr is not None else None
        tid = x.get("onTeamId")
        rows.append({"id": x["id"], "name": name, "team": L.tri(PRO_TEAM_MAP.get(pl.get("proTeamId"), "FA")),
                     "owner": team_name.get(tid, "") if tid in team_name else "", "own": round(pl.get("ownership", {}).get("percentOwned", 0.0), 1),
                     "inj": pl.get("injuryStatus", "ACTIVE"), "espn_rank": int(r.get("statCategoryRanking") or 0),
                     "e": [e[c] for c in L.CATS], "u": u, "pg": _pg(pr["r"]) if pr is not None else None, "elig": [L.POS_ID[s] for s in pl.get("eligibleSlots", []) if s in L.POS_ID]})
    fit = [r for r in rows if r["u"] is not None and 0 < r["espn_rank"] <= FIT_TOP]
    eu_t = np.array([sum(r["e"]) for r in fit]); ou_t = np.array([r["u"].sum() for r in fit])
    scale = float(eu_t.std() / (ou_t.std() or 1.0))                    # one scale for all categories (per-category matching amplified noise in the % cats)
    cal = [(float(np.mean([r["u"][i] for r in fit])), float(np.mean([r["e"][i] for r in fit]))) for i in range(13)]
    for r in rows:
        if r["u"] is None:
            r["our"], r["our_tot"] = None, None
            continue
        r["our"] = [round((r["u"][i] - cal[i][0]) * scale + cal[i][1], 2) for i in range(13)]
        r["our_tot"] = round(sum(r["our"]), 2)
    proj_rows = [r for r in rows if r["our"] is not None]
    for k, r in enumerate(sorted(proj_rows, key=lambda r: -r["our_tot"])):
        r["our_rank"] = k + 1
    for k, r in enumerate(sorted(proj_rows, key=lambda r: r["espn_rank"] or 9999)):
        r["espn_rank_adj"] = k + 1
    out = []
    for r in rows:
        et = round(sum(r["e"]), 2)
        d = {"id": r["id"], "name": r["name"], "team": r["team"], "owner": r["owner"], "own": r["own"], "inj": r["inj"], "elig": r["elig"],
             "espn_rank": r["espn_rank"], "espn_tot": et, "espn": [round(v, 2) for v in r["e"]], "our": r["our"], "our_tot": r["our_tot"],
             "our_rank": r.get("our_rank"), "d_tot": round(r["our_tot"] - et, 2) if r["our"] else None,
             "d_rank": (r["espn_rank_adj"] - r["our_rank"]) if r["our"] else None,
             "d": [round(r["our"][i] - r["e"][i], 2) for i in range(13)] if r["our"] else None,
             "pg": {k: round(v, 3) for k, v in r["pg"].items()} if r["pg"] else None}
        out.append(d)
    out.sort(key=lambda d: d["espn_rank"] or 9999)
    rater = {"cats": [L.LABEL[c] for c in L.CATS], "keys": list(L.CATS), "rows": out, "n_fit": len(fit), "scale": round(scale, 2),
             "corr": float(np.corrcoef([r["espn_tot"] for r in out if r["our"]], [r["our_tot"] for r in out if r["our"]])[0, 1]) if proj_rows else None,
             "no_model": sum(1 for r in out if not r["our"])}
    by_team = {}
    for d in out:
        for tid, t in E["teams"].items():
            if d["owner"] == t["name"]:
                by_team.setdefault(str(tid), []).append(d["id"])
    rost = {}
    byid = {d["id"]: d for d in out}
    for tid, t in E["teams"].items():
        lst = []
        for p in t["roster"]:
            d = byid.get(p["id"])
            lst.append(d if d else {"id": p["id"], "name": p["name"], "team": p["team"], "inj": p["inj"], "elig": [], "espn": None, "our": None, "pg": None,
                                    "espn_tot": None, "our_tot": None, "d_tot": None, "espn_rank": None, "our_rank": None, "own": 100.0, "owner": t["name"]})
        lst.sort(key=lambda d: -(d["our_tot"] if d["our_tot"] is not None else (d["espn_tot"] if d["espn_tot"] is not None else -99)))
        rost[str(tid)] = [{k: d[k] for k in ("id", "name", "team", "inj", "elig", "espn", "our", "pg", "espn_tot", "our_tot", "d_tot", "espn_rank", "our_rank")} for d in lst]
    for d in out:
        d.pop("pg", None)
    return rater, rost
