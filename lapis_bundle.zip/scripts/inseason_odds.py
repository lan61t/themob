"""Vegas lines (spread, total) for upcoming games from ESPN's public core API (no login). Display-only: the backtest
(research_odds_effect.py) found the lines move minutes only a little (+-1.7 min in blowouts), so they flag blowout risk but do not change win chances."""
import json
import time
from datetime import date
from pathlib import Path

import requests

CACHE = Path(__file__).resolve().parent.parent / "data" / "live" / "odds.json"
FIX = {"GS": "GSW", "NY": "NYK", "SA": "SAS", "NO": "NOP", "UTAH": "UTA", "WSH": "WAS"}
BLOWOUT = 10.0
_S = requests.Session()


def _get(u):
    for _ in range(2):
        try:
            r = _S.get(u, timeout=12)
            if r.ok:
                return r.json()
        except Exception:
            pass
    return None


def _day(d: date) -> dict:
    j = _get(f"https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard?dates={d:%Y%m%d}&limit=30") or {}
    out = {}
    for e in j.get("events", []):
        tm = {t["homeAway"]: FIX.get(t["team"]["abbreviation"], t["team"]["abbreviation"]) for t in e["competitions"][0]["competitors"]}
        o = (_get(f"https://sports.core.api.espn.com/v2/sports/basketball/leagues/nba/events/{e['id']}/competitions/{e['id']}/odds") or {}).get("items") or []
        if o and o[0].get("spread") is not None and len(tm) == 2:
            sp, tot = float(o[0]["spread"]), o[0].get("overUnder")
            out[tm["home"]] = {"spread": sp, "total": tot, "opp": tm["away"]}
            out[tm["away"]] = {"spread": -sp, "total": tot, "opp": tm["home"]}
    return out


NEAR_DAYS, NEAR_TTL, FAR_TTL = 1, 0, 6 * 3600       # today/tomorrow are re-read on every build; later days every 6 h


def refresh(days, today=None) -> dict:
    """days: iterable of dates. Returns {'YYYY-MM-DD': {team: {spread, total, opp}, '_at': epoch}} (spread from the team's view, negative =
    favourite). Lines move (injury news, sharp money), so near days are re-fetched every time and every day keeps the time it was read."""
    today = today or date.today()
    old = load()
    now = time.time()
    res = {}
    for d in days:
        k = d.isoformat()
        ttl = NEAR_TTL if (d - today).days <= NEAR_DAYS else FAR_TTL
        if k in old and now - old[k].get("_at", 0) < ttl:
            res[k] = old[k]
            continue
        r = _day(d)
        if r:
            r["_at"] = now
            res[k] = r
        elif k in old:                                        # fetch failed: keep the old line rather than show nothing
            res[k] = old[k]
    try:
        CACHE.write_text(json.dumps(res))
    except Exception:
        pass
    return res


def load() -> dict:
    try:
        return json.loads(CACHE.read_text())
    except Exception:
        return {}


def note(odds: dict, day: date, team: str, today=None):
    """{'text','blowout','early'} for a team on a date, or None. Lines for days more than a day out are early lines and may move."""
    row = odds.get(day.isoformat()) or {}
    x = row.get(FIX.get(team, team))
    if not x:
        return None
    sp = x["spread"]
    early = (day - (today or date.today())).days > NEAR_DAYS
    txt = f"{'fav' if sp < 0 else 'dog'} {sp:+.1f}" + (f" · O/U {x['total']:.0f}" if x.get("total") else "") + (" · early line" if early else "")
    return {"text": txt, "blowout": abs(sp) >= BLOWOUT and not early, "early": early, "at": row.get("_at")}
