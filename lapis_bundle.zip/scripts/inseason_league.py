"""League-wide dynamic team stats for the Lapis league: every team's category strengths / weaknesses, power rating, and a log of every
roster movement with the before/after effect on that team.

team_strengths(): for each of the 14 teams, plan the next N weeks of starts (same allocator and rules as the matchup engine, real
schedule, current injuries) and average the weekly category totals. Per category it gives the team's z-score and rank (1 = best,
TO/PF inverted); strengths = z >= +0.8, weaknesses = z <= -0.8. Power = average chance of beating each of the other 13 teams in a week.
track_moves(): compares this refresh's rosters with the saved snapshot (data/live/league_snapshot.json). Added/dropped players become
events in data/live/moves_log.json; a player dropped by one team and added by another in the same interval is labelled a TRADE.
Each event carries the team's category ranks and power before and after.

Limit: ESPN's transaction list needs a login, so movements are detected by snapshot diff while the app is running; if it was closed,
the next refresh reports the net change since the last snapshot (with both timestamps) instead of individual timestamps.
"""
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_live as L  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

CACHE = L.LIVE
SNAP, LOG = CACHE / "league_snapshot.json", CACHE / "moves_log.json"
STRONG, WEAK = 0.8, -0.8
N_WEEKS = 4


def _players(recs, proj):
    out = []
    for rec in recs:
        pr = proj.get(L.norm(rec["name"])) or L.fallback_projection(rec["name"])
        if pr is not None:
            out.append(L.mk_player(rec, pr))
    return out


def team_strengths(E, proj, today, mp, n_weeks=N_WEEKS):
    wks = []
    for m in range(mp, min(L.LC.C["n_periods"], mp + n_weeks - 1) + 1):
        start = L.period_bounds(m)[0]
        wks.append(L.Week(m, datetime(2000, 1, 1), start - timedelta(days=1), real_today=today))
    tot, var, names, allnames = {}, {}, {}, {}
    for tid, t in E["teams"].items():
        pl = _players(t["roster"], proj)
        names[tid] = [p["name"] for p in pl]
        allnames[tid] = [r["name"] for r in t["roster"]]          # everyone ESPN lists, projected or not (moves must not depend on a projection)
        ts, vs = [], []
        for wk in wks:
            pk = L.team_pack(pl, wk, None, L.BAL)
            a, v = L.aggregate(pk)
            ts.append(a); vs.append(v)
        tot[tid], var[tid] = np.mean(ts, axis=0), np.mean(vs, axis=0)
    ids = list(E["teams"])
    val = {tid: L.cat_values(tot[tid]) for tid in ids}
    z, rank = {tid: {} for tid in ids}, {tid: {} for tid in ids}
    for c in L.CATS:
        x = np.array([val[tid][c] for tid in ids])
        sd = x.std() or 1.0
        s = (x - x.mean()) / sd
        if c in L.LOWER_BETTER:
            s = -s
        order = (-s).argsort().argsort() + 1
        for k, tid in enumerate(ids):
            z[tid][c], rank[tid][c] = float(s[k]), int(order[k])
    power = {}
    for a in ids:
        ps = [L.evaluate(tot[a], var[a], tot[b], var[b])[1] for b in ids if b != a]
        power[a] = float(np.mean(ps))
    out = {}
    for tid in ids:
        t = E["teams"][tid]
        strong = sorted([c for c in L.CATS if z[tid][c] >= STRONG], key=lambda c: -z[tid][c])
        weak = sorted([c for c in L.CATS if z[tid][c] <= WEAK], key=lambda c: z[tid][c])
        out[tid] = {"id": tid, "name": t["name"], "owner": t["owner"], "power": power[tid], "z": z[tid], "rank": rank[tid],
                    "strengths": [L.LABEL[c] for c in strong], "weaknesses": [L.LABEL[c] for c in weak],
                    "players": names[tid], "roster_all": allnames[tid], "weeks": [w.mp for w in wks]}
    order = sorted(out, key=lambda t: -out[t]["power"])
    for i, tid in enumerate(order):
        out[tid]["power_rank"] = i + 1
    return out


def partners(strengths, my_id, k=5):
    """Teams whose strengths cover my weak categories and whose weak categories I cover (trade-fit, not a trade recommendation)."""
    me = strengths[my_id]["z"]
    rows = []
    for tid, s in strengths.items():
        if tid == my_id:
            continue
        give = [(c, me[c]) for c in L.CATS if me[c] >= 0.5 and s["z"][c] <= -0.5]      # I am strong where they are weak
        get = [(c, s["z"][c]) for c in L.CATS if s["z"][c] >= 0.5 and me[c] <= -0.5]     # they are strong where I am weak
        score = sum(v * -s["z"][c] for c, v in give) + sum(v * -me[c] for c, v in get)
        rows.append({"id": tid, "name": s["name"], "score": float(score), "you_offer": [L.LABEL[c] for c, _ in give],
                     "they_offer": [L.LABEL[c] for c, _ in get]})
    return sorted(rows, key=lambda r: -r["score"])[:k]


def _load(p, default):
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))      # tolerate a BOM (Windows editors add one)
    except Exception:
        return default


def track_moves(strengths, now_utc):
    """Diff rosters against the saved snapshot; append events; save the new snapshot. Returns (events_this_refresh, recent_log)."""
    CACHE.mkdir(parents=True, exist_ok=True)
    prev = _load(SNAP, None)
    log = _load(LOG, [])
    ts = now_utc.strftime("%Y-%m-%d %H:%M UTC")
    new = {str(tid): {"name": s["name"], "roster": s["roster_all"], "projected": s["players"], "z": s["z"], "rank": s["rank"], "power": s["power"]} for tid, s in strengths.items()}
    events = []
    legacy = bool(prev) and any("projected" not in t for t in prev["teams"].values())     # snapshots before 2026-10-15 held projected players only
    if legacy:
        for t in prev["teams"].values():
            t["projected"] = list(t["roster"])
    if prev:
        added, dropped = {}, {}
        for tid, cur in new.items():
            old = prev["teams"].get(tid)
            if not old:
                continue
            added[tid] = [p for p in cur["roster"] if p not in old["roster"] and not (legacy and p not in cur["projected"])]
            dropped[tid] = [p for p in old["roster"] if p not in cur["roster"]]
        for tid, cur in new.items():
            old = prev["teams"].get(tid)
            if not old or not (added[tid] or dropped[tid]):
                continue
            partner = None
            for p in dropped[tid]:                              # dropped here, added elsewhere = traded away
                for oid, ad in added.items():
                    if oid != tid and p in ad:
                        partner = new[oid]["name"]
            for p in added[tid]:
                for oid, dr in dropped.items():
                    if oid != tid and p in dr:
                        partner = new[oid]["name"]
            dz = {c: cur["z"][c] - old["z"][c] for c in L.CATS}
            changes = sorted([c for c in L.CATS if cur["rank"][c] != old["rank"][c] and abs(dz[c]) >= 0.15], key=lambda c: -abs(dz[c]))[:6]
            events.append({"ts": ts, "since": prev["ts"], "team_id": int(tid), "team": cur["name"], "kind": "TRADE" if partner else "MOVE",
                           "no_proj": [p for p in added[tid] if p not in cur["projected"]],
                           "partner": partner, "in": added[tid], "out": dropped[tid],
                           "power_from": old["power"], "power_to": cur["power"],
                           "cats": [{"cat": L.LABEL[c], "rank_from": old["rank"][c], "rank_to": cur["rank"][c], "dz": dz[c]} for c in changes]})
    # power before each team's latest roster change (so the page can show "+3 pts since X moved"); unchanged teams keep their reference
    for tid, cur in new.items():
        old = (prev or {}).get("teams", {}).get(tid)
        changed = bool(old) and (set(cur["roster"]) != set(old["roster"]) if not legacy else set(cur["projected"]) != set(old["projected"]))
        cur["ref_power"] = old["power"] if changed else (old.get("ref_power", old["power"]) if old else cur["power"])
        cur["changed_ts"] = ts if changed else (old.get("changed_ts") if old else None)
        if int(tid) in strengths:
            strengths[int(tid)]["power_ref"], strengths[int(tid)]["changed_ts"] = cur["ref_power"], cur["changed_ts"]
    json.dump({"ts": ts, "teams": new}, open(SNAP, "w", encoding="utf-8"), default=float)
    if events:
        log = (events + log)[:300]
        json.dump(log, open(LOG, "w", encoding="utf-8"), default=float)
    if legacy:                                          # one-time repair: an earlier event with more drops than adds was missing an unprojected add
        for tid, cur in new.items():
            unproj = [p for p in cur["roster"] if p not in cur["projected"]]
            ev = next((e for e in log if str(e["team_id"]) == tid), None)
            if unproj and ev and len(ev["out"]) > len(ev["in"]) and not set(unproj) & set(ev["in"]):
                ev["in"] = ev["in"] + unproj[:len(ev["out"]) - len(ev["in"])]
                ev["no_proj"] = unproj
                json.dump(log, open(LOG, "w", encoding="utf-8"), default=float)
    return events, log[:40]


def league_block(E, proj, today, mp, now_utc, my_id, opp_id):
    st = team_strengths(E, proj, today, mp)
    events, recent = track_moves(st, now_utc)
    teams = sorted(st.values(), key=lambda s: s["power_rank"])
    return {"teams": [{**t, "is_me": t["id"] == my_id, "is_opp": t["id"] == opp_id} for t in teams], "partners": partners(st, my_id),
            "moves": recent, "new_moves": len(events), "tracking_since": (_load(SNAP, {}) or {}).get("ts"),
            "cats": [L.LABEL[c] for c in L.CATS], "weeks": st[my_id]["weeks"]}, st


if __name__ == "__main__":
    E = L.pull_espn(1, 1, L.now_nba()[1])
    proj = L.load_projections()
    blk, st = league_block(E, proj, L.now_nba()[1], 1, L.now_nba()[0], L.MY_TEAM, 30)
    for t in blk["teams"]:
        print(f"{t['power_rank']:2d}. {t['name'][:26]:26s} power {t['power']:.0%}  strong: {', '.join(t['strengths']) or '-':28s} weak: {', '.join(t['weaknesses']) or '-'}")
    print("partners for me:", [(p["name"], round(p["score"], 1), p["they_offer"]) for p in blk["partners"][:3]])
    print("moves logged:", blk["new_moves"], "| tracking since", blk["tracking_since"])
