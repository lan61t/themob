"""Trade lab for the Lapis / T27A apps.

 (1) analyse a trade the user types in (any partner, any players) with the same engine that rates the rosters,
 (2) find the best partners for the players the user wants to send,
 (3) export a compact copy of the engine's inputs so the static page can re-run the maths in the browser (no server online).

The baseline of every team (4 weeks of real schedule) is built once in `Lab`, then any trade is scored by rebuilding only the two teams
that change and comparing power = average chance of beating each other team in a week, plus per-category strength before and after.
After a trade a roster that is short is filled with the best free agent and one that is long drops its weakest player.
"""
import sys
from datetime import timedelta
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402
import inseason_trade as T  # noqa: E402
from inseason_trade import _eff, _power, _settle, _tv, _weeks  # noqa: E402


def _key(n):
    return "".join(c for c in n.lower() if c.isalnum())


def verdict(d_me, d_them):
    if d_me >= T.MIN_ME and d_them >= 0.002:
        return "WIN-WIN"
    if d_me >= T.MIN_ME and d_them >= T.MIN_THEM:
        return "FAIR"
    if d_me >= T.MIN_ME:
        return "ONE-SIDED"
    if d_me >= -0.002 and d_them >= 0.002:
        return "FAVOURS THEM"
    return "NO"


class Lab:
    """Holds the baseline of every team once, then scores any trade quickly."""

    def __init__(self, E, proj, today, mp, my_id, league, fa_pl):
        from inseason_league import _players
        self.E, self.today, self.my_id, self.fa_pl = E, today, my_id, fa_pl
        self.wks = _weeks(today, mp)
        self.z_by = {t["id"]: t["z"] for t in league["teams"]}
        self.rosters = {tid: _players(t["roster"], proj) for tid, t in E["teams"].items()}
        self.ids = list(self.rosters)
        self.size = {tid: len(self.rosters[tid]) for tid in self.ids}
        base = {tid: _tv(self.rosters[tid], self.wks) for tid in self.ids}
        self.tot = {tid: base[tid][0] for tid in self.ids}
        self.var = {tid: base[tid][1] for tid in self.ids}
        self.pw0 = {tid: _power(tid, self.tot, self.var) for tid in self.ids}
        vals0 = {tid: L.cat_values(self.tot[tid]) for tid in self.ids}
        self.cm = {c: np.mean([vals0[t][c] for t in self.ids]) for c in L.CATS}
        self.cs = {c: (np.std([vals0[t][c] for t in self.ids]) or 1.0) for c in L.CATS}
        self.z0 = {tid: self._zcat(vals0[tid]) for tid in self.ids}
        self.fill = sorted([f for f in fa_pl if str(f.get("inj") or "ACTIVE").upper() in ("ACTIVE", "DAY_TO_DAY")],
                           key=lambda f: -_eff(f, L.BAL, today))
        self.owner = {}
        for tid in self.ids:
            for p in self.rosters[tid]:
                self.owner[_key(p["name"])] = tid

    def _zcat(self, v):
        return {c: ((v[c] - self.cm[c]) / self.cs[c]) * (-1 if c in L.LOWER_BETTER else 1) for c in L.CATS}

    def _wts(self, tid):
        return FA._cat_weights(self.z_by[tid])[0]

    def scenario(self, pid, give_names, get_names):
        """Exact check of one trade between my team and `pid`. Raises ValueError for a name that is not on the right roster."""
        me = self.my_id
        mine, theirs = self.rosters[me], self.rosters[pid]
        gk, tk = {_key(n) for n in give_names}, {_key(n) for n in get_names}
        give = [p for p in mine if _key(p["name"]) in gk]
        get = [p for p in theirs if _key(p["name"]) in tk]
        if len(give) != len(gk) or len(get) != len(tk) or not give or not get:
            have_m, have_t = {_key(p["name"]) for p in mine}, {_key(p["name"]) for p in theirs}
            missing = [n for n in give_names if _key(n) not in have_m] + [n for n in get_names if _key(n) not in have_t]
            raise ValueError("not on the roster (or has no projection): " + ", ".join(missing or ["?"]))
        g_names, t_names = {p["name"] for p in give}, {p["name"] for p in get}
        wm, wp = self._wts(me), self._wts(pid)
        em_all = {p["name"]: _eff(p, wm, self.today) for p in mine + theirs}
        ep_all = {p["name"]: _eff(p, wp, self.today) for p in mine + theirs}
        new_me = [p for p in mine if p["name"] not in g_names] + get
        new_th = [p for p in theirs if p["name"] not in t_names] + give
        new_me, add_me = _settle(new_me, self.size[me], self.fill, t_names, {p["name"]: em_all[p["name"]] for p in new_me})
        new_th, add_th = _settle(new_th, self.size[pid], self.fill, g_names, {p["name"]: ep_all[p["name"]] for p in new_th})
        keep_me, keep_th = {q["name"] for q in new_me}, {q["name"] for q in new_th}
        a1, v1 = _tv(new_me, self.wks)
        a2, v2 = _tv(new_th, self.wks)
        tot2, var2 = dict(self.tot), dict(self.var)
        tot2[me], var2[me], tot2[pid], var2[pid] = a1, v1, a2, v2
        pm, pt = _power(me, tot2, var2), _power(pid, tot2, var2)
        zm, zt = self._zcat(L.cat_values(a1)), self._zcat(L.cat_values(a2))

        def cats(tt, vv, a):                       # per-category win chance averaged over the other 13 teams
            return np.mean([L.evaluate(tt[a], vv[a], tt[b], vv[b])[0] for b in tt if b != a], axis=0)

        cm0, cm1 = cats(self.tot, self.var, me), cats(tot2, var2, me)
        ct0, ct1 = cats(self.tot, self.var, pid), cats(tot2, var2, pid)

        def rows(z0, z1, c0, c1):
            return [{"cat": L.LABEL[c], "z0": float(z0[c]), "z1": float(z1[c]), "dz": float(z1[c] - z0[c]),
                     "p0": float(c0[i]), "p1": float(c1[i])} for i, c in enumerate(L.CATS)]

        def info(p, w):
            return {"name": p["name"], "team": p["team"], "elig": sorted(p["elig"]), "inj": p["inj"],
                    "pg": {c: float(p["r"][L.CI[c]]) for c in L.COMP},
                    "avail": round(FA.avail_frac(p, self.today)[0], 3), "eff": round(_eff(p, w, self.today), 3)}

        rm, rt = rows(self.z0[me], zm, cm0, cm1), rows(self.z0[pid], zt, ct0, ct1)
        d_me, d_th = pm - self.pw0[me], pt - self.pw0[pid]
        out = {"partner_id": pid, "partner": self.E["teams"][pid]["name"], "owner": self.E["teams"][pid]["owner"],
               "give": [p["name"] for p in give], "get": [p["name"] for p in get], "kind": f"{len(give)}-for-{len(get)}",
               "fill_me": add_me, "fill_them": add_th,
               "drop_me": [p["name"] for p in mine if p["name"] not in g_names and p["name"] not in keep_me],
               "drop_them": [p["name"] for p in theirs if p["name"] not in t_names and p["name"] not in keep_th],
               "me_from": self.pw0[me], "me_to": pm, "them_from": self.pw0[pid], "them_to": pt, "d_me": d_me, "d_them": d_th,
               "me_cat": rm, "them_cat": rt,
               "give_info": [info(p, wm) for p in give], "get_info": [info(p, wm) for p in get],
               "me_cats": [{"cat": r["cat"], "dz": r["dz"]} for r in sorted(rm, key=lambda r: -abs(r["dz"])) if abs(r["dz"]) >= 0.2][:5],
               "them_cats": [{"cat": r["cat"], "dz": r["dz"]} for r in sorted(rt, key=lambda r: -abs(r["dz"])) if abs(r["dz"]) >= 0.2][:5],
               "weeks": [w.mp for w in self.wks]}
        out["verdict"] = verdict(d_me, d_th)
        return out

    def search(self, give_names, per_partner=3, top=12, partners=None):
        """Best partners for the players I want to send: every 1- or 2-player package from each partner that includes ALL of `give_names`
        (plus one more of mine when I named just one), screened with the team-value proxy and checked exactly."""
        me = self.my_id
        gk = {_key(n) for n in give_names}
        mine = self.rosters[me]
        base_give = [p for p in mine if _key(p["name"]) in gk]
        if not base_give or len(base_give) != len(gk) or len(base_give) > 2:
            raise ValueError("choose 1 or 2 of your own players to send")
        wm = self._wts(me)
        em = {p["name"]: _eff(p, wm, self.today) for p in mine}
        b_me = FA.team_value(list(em.values()))
        res = []
        for pid in (partners or [i for i in self.ids if i != me]):
            theirs = self.rosters[pid]
            wp = self._wts(pid)
            ep = {p["name"]: _eff(p, wp, self.today) for p in theirs}
            em_all = {**em, **{p["name"]: _eff(p, wm, self.today) for p in theirs}}
            ep_all = {**ep, **{p["name"]: _eff(p, wp, self.today) for p in mine}}
            b_th = FA.team_value(list(ep.values()))
            gives = [tuple(base_give)]
            if len(base_give) == 1:
                gives += [tuple(base_give) + (q,) for q in mine if q is not base_give[0]]
            cands = []
            for give in gives:
                for nt in (1, 2):
                    if len(give) == 2 and nt == 2 and len(base_give) == 1:
                        continue                                      # 2-for-2 only when the user chose both players himself
                    for get in combinations(theirs, nt):
                        g_n, t_n = {p["name"] for p in give}, {p["name"] for p in get}
                        new_me = [p for p in mine if p["name"] not in g_n] + list(get)
                        new_th = [p for p in theirs if p["name"] not in t_n] + list(give)
                        v_me = sorted([em_all[p["name"]] for p in new_me], reverse=True)[:self.size[me]]
                        v_th = sorted([ep_all[p["name"]] for p in new_th], reverse=True)[:self.size[pid]]
                        d_me, d_th = FA.team_value(v_me) - b_me, FA.team_value(v_th) - b_th
                        if d_me > 0.0 and d_th > -0.6:
                            cands.append((d_me + 1.5 * min(d_th, 0.3), give, get))
            cands.sort(key=lambda x: -x[0])
            for _, give, get in cands[:per_partner]:
                try:
                    res.append(self.scenario(pid, [p["name"] for p in give], [p["name"] for p in get]))
                except ValueError:
                    pass
        rank = {"WIN-WIN": 0, "FAIR": 1, "ONE-SIDED": 2}
        res = [r for r in res if r["verdict"] in rank]
        res.sort(key=lambda r: (rank[r["verdict"]], -r["d_me"]))
        keep, per = [], {}
        for r in res:
            if per.get(r["partner_id"], 0) < 2:
                keep.append(r)
                per[r["partner_id"]] = per.get(r["partner_id"], 0) + 1
            if len(keep) >= top:
                break
        return keep

    # ------------------------------------------------------------------ browser copy
    def export_lite(self, n_fa=8):
        """Inputs the page needs to re-run team_pack/aggregate/evaluate for any two rosters."""
        def rnd(a, k=3):
            return [round(float(x), k) for x in a]
        names = {}
        for tid in self.ids:
            for p in self.rosters[tid]:
                names[p["name"]] = (p, tid)
        for p in self.fill[:n_fa]:
            names.setdefault(p["name"], (p, None))
        pdays_w = [w.play_days() for w in self.wks]
        players = {}
        for nm, (p, tid) in names.items():
            val = float((p["u"] * L.BAL).sum() / L.G_AVG)
            pv, am = [], []
            for w, pdays in zip(self.wks, pdays_w):
                days = pdays.get(p["team"], set())
                pr, ar = [], []
                for d in range(w.n):
                    day = w.start + timedelta(days=d)
                    pr.append(round(L.day_p(p["inj"], p.get("ret"), p.get("base"), day, w.real_today), 3) if d in days else 0.0)
                    m, _ = L.absence_m(p["team"], L.norm(p["name"]), day, w.real_today)
                    ar.append(round(float(m), 3) if m > 0.01 else 0.0)
                pv.append(pr)
                am.append(ar)
            players[nm] = {"team": p["team"], "elig": sorted(p["elig"]), "inj": p["inj"], "r": rnd(p["r"], 4), "val": round(val, 4), "u": rnd(p["u"], 3),
                           "p": pv, "am": am, "avail": round(FA.avail_frac(p, self.today)[0], 3),
                           "owner": None if tid is None else str(tid)}
        q = L.Q
        return {
            "cats": L.CATS, "labels": [L.LABEL[c] for c in L.CATS], "comp": L.COMP,
            "weeks": [{"mp": w.mp, "n": w.n, "cap": w.cap, "sun": w.sun} for w in self.wks],
            "sun_cap": L.SUN_CAP, "has_cap": bool(L.HAS_CAP), "buffer": 1.0,
            "abs_k": rnd(L.ABS_K, 4), "kappa": float(L.ABS_KAPPA),
            "u0": rnd(FA.U0, 4), "fit_tilt": FA.FIT_TILT, "depth": rnd(FA.CFG["depth"], 4),
            "keep": [_key(n) for n in L.LC.KEEP],
            "slots": list(L.A.SLOTS), "slot_ok": {k: sorted(v) for k, v in L.A.SLOT_OK.items()},
            "tau": rnd(L.G.TAU, 5), "bal": rnd(L.BAL, 5), "g_avg": L.G_AVG,
            "sd": [float(q["imp_sd"][c] if c in L.PCT else q["sd"][c]) for c in L.CATS],
            "comp_q": {c: float(q["comp"][c]) for c in L.PCT}, "pct": {c: list(v) for c, v in L.PCT.items()},
            "lower": sorted(L.LOWER_BETTER),
            "teams": {str(tid): {"name": self.E["teams"][tid]["name"], "owner": self.E["teams"][tid]["owner"],
                                 "players": [p["name"] for p in self.rosters[tid]], "size": self.size[tid],
                                 "tot": rnd(self.tot[tid], 4), "var": rnd(self.var[tid], 4), "power": float(self.pw0[tid]),
                                 "z": {c: float(self.z0[tid][c]) for c in L.CATS}} for tid in self.ids},
            "me": str(self.my_id), "players": players, "fill": [p["name"] for p in self.fill[:n_fa]],
            "avg_cat": {"mean": {c: float(self.cm[c]) for c in L.CATS}, "sd": {c: float(self.cs[c]) for c in L.CATS}},
        }
