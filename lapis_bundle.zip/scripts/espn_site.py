"""ESPN public site API: schedule, box scores, injuries. No login, no API key, and (unlike stats.nba.com) it answers from cloud servers,
so the online version of the app can use it.

  scoreboard(d)        games on a date: id, tip (UTC), state pre/in/post, teams, score
  box_lines(d)         every player line of the FINAL games on a date, in the column names the rest of the app uses
  injuries()           current injury list with status, detail, return date, fantasy status and the newest comment, by player name
  schedule_rows(d0,d1) upcoming games as (date, team, opp, home, tip) rows, used to patch the cached season schedule (NBA Cup, postponements)
Finished-game box scores are cached under data/live/espn_box_<event>.json so they are fetched once.
"""
import json
import re
import sys
import time
import unicodedata
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import requests

try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "data" / "live"
BASE = "https://site.api.espn.com/apis/site/v2/sports/basketball/nba"
H = {"User-Agent": "Mozilla/5.0 (lapis-daily)"}
ALIAS = {"NY": "NYK", "GS": "GSW", "SA": "SAS", "NO": "NOP", "UTAH": "UTA", "WSH": "WAS", "PHO": "PHX", "PHL": "PHI"}
KEYS = ["minutes", "points", "fg", "fg3", "ft", "reb", "ast", "to", "stl", "blk", "oreb", "dreb", "pf", "pm"]


def tri(a):
    return ALIAS.get(a, a)


def norm(s):
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\b(jr|sr|ii|iii|iv)\b\.?", "", s)
    return re.sub(r"[^a-z]", "", s)


def _get(path, params=None, tries=3):
    last = None
    for i in range(tries):
        try:
            r = requests.get(BASE + path, params=params, headers=H, timeout=30)
            if r.status_code == 200:
                return r.json()
            last = f"HTTP {r.status_code}"
        except Exception as e:
            last = f"{type(e).__name__}: {e}"
        time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"ESPN {path} failed: {last}")


def _utc(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%MZ")


def scoreboard(d):
    j = _get("/scoreboard", {"dates": d.strftime("%Y%m%d")})
    out = []
    for e in j.get("events", []):
        comp = e["competitions"][0]
        cs = {c["homeAway"]: c for c in comp["competitors"]}
        out.append({"id": e["id"], "tip": _utc(e["date"]), "state": e["status"]["type"]["state"], "done": bool(e["status"]["type"]["completed"]),
                    "home": tri(cs["home"]["team"]["abbreviation"]), "away": tri(cs["away"]["team"]["abbreviation"]),
                    "home_score": int(cs["home"].get("score") or 0), "away_score": int(cs["away"].get("score") or 0),
                    "label": ((comp.get("notes") or [{}])[0].get("headline") or "") if comp.get("notes") else ""})
    return out


def _pair(s):
    try:
        a, b = str(s).split("-")
        return int(a), int(b)
    except Exception:
        return 0, 0


def _box(event_id, home, away, hs, as_):
    f = CACHE / f"espn_box_{event_id}.json"
    if f.exists():
        return json.loads(f.read_text(encoding="utf-8"))
    j = _get("/summary", {"event": event_id})
    lines = []
    for t in j["boxscore"]["players"]:
        team = tri(t["team"]["abbreviation"])
        if not t.get("statistics"):
            continue
        keys = t["statistics"][0]["keys"]
        for a in t["statistics"][0]["athletes"]:
            if a.get("didNotPlay") or not a.get("stats"):
                continue
            row = dict(zip(keys, a["stats"]))
            try:
                mins = float(row.get("minutes") or 0)
            except ValueError:
                mins = 0.0
            if mins <= 0:
                continue
            fgm, fga = _pair(row.get("fieldGoalsMade-fieldGoalsAttempted"))
            f3m, f3a = _pair(row.get("threePointFieldGoalsMade-threePointFieldGoalsAttempted"))
            ftm, fta = _pair(row.get("freeThrowsMade-freeThrowsAttempted"))
            pm = str(row.get("plusMinus", "0")).replace("+", "")
            lines.append({"PLAYER_ID": int(a["athlete"]["id"]), "PLAYER_NAME": a["athlete"]["displayName"], "TEAM_ABBREVIATION": team,
                          "GAME_ID": event_id, "MIN": mins, "FGM": fgm, "FGA": fga, "FG3M": f3m, "FG3A": f3a, "FTM": ftm, "FTA": fta,
                          "OREB": int(row.get("offensiveRebounds") or 0), "DREB": int(row.get("defensiveRebounds") or 0),
                          "AST": int(row.get("assists") or 0), "TOV": int(row.get("turnovers") or 0), "STL": int(row.get("steals") or 0),
                          "BLK": int(row.get("blocks") or 0), "PF": int(row.get("fouls") or 0), "PTS": int(row.get("points") or 0),
                          "PLUS_MINUS": int(pm) if re.fullmatch(r"-?\d+", pm) else 0, "STARTER": bool(a.get("starter"))})
    res = {"id": event_id, "home": home, "away": away, "home_score": hs, "away_score": as_, "lines": lines}
    CACHE.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(res), encoding="utf-8")
    return res


def box_lines(d):
    """All player lines of the finished games on date d (ESPN's date, i.e. the US game day)."""
    games = [g for g in scoreboard(d) if g["done"]]
    lines, meta, final = [], {}, True
    for g in games:
        b = _box(g["id"], g["home"], g["away"], g["home_score"], g["away_score"])
        lines += b["lines"]
        meta[g["id"]] = {"matchup": f"{g['away']} @ {g['home']}", "pts": {g["away"]: g["away_score"], g["home"]: g["home_score"]},
                         "label": g["label"]}
    n_all = len(scoreboard(d))
    return {"date": d.isoformat(), "lines": lines, "games": meta, "all_final": len(games) == n_all and n_all > 0}


def injuries():
    """name-key -> {name, team, status, fantasy, detail, ret, comment, date}"""
    j = _get("/injuries")
    out = {}
    for t in j.get("injuries", []):
        for i in t.get("injuries", []):
            a = i.get("athlete", {})
            nm = a.get("displayName")
            if not nm:
                continue
            det = i.get("details", {}) or {}
            out[norm(nm)] = {"name": nm, "team": tri((a.get("team") or {}).get("abbreviation", "")), "status": i.get("status", ""),
                             "fantasy": (det.get("fantasyStatus") or {}).get("abbreviation", ""),
                             "detail": " ".join(x for x in [det.get("side"), det.get("type"), det.get("detail")] if x),
                             "ret": det.get("returnDate"), "comment": i.get("shortComment", ""), "date": i.get("date", "")}
    return out


def schedule_rows(d0, d1):
    rows, d = [], d0
    while d <= d1:
        for g in scoreboard(d):
            et = (g["tip"] - timedelta(hours=5)).date()
            rows.append((et, g["home"], g["away"], True, "E" + g["id"], g["tip"]))
            rows.append((et, g["away"], g["home"], False, "E" + g["id"], g["tip"]))
        d += timedelta(days=1)
    return rows


if __name__ == "__main__":
    d = date(2026, 10, 13)
    r = box_lines(d)
    print(d, len(r["lines"]), "lines,", len(r["games"]), "games, all_final", r["all_final"])
    top = sorted(r["lines"], key=lambda x: -x["PTS"])[:3]
    print([(x["PLAYER_NAME"], x["TEAM_ABBREVIATION"], x["MIN"], x["PTS"], x["STARTER"]) for x in top])
    inj = injuries(); print(len(inj), "injury rows; sample:", list(inj.values())[0]["name"], list(inj.values())[0]["ret"])
    print(len(schedule_rows(date(2026, 10, 20), date(2026, 10, 21))), "schedule rows for Oct 20-21")
