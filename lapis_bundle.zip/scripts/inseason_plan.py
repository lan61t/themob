"""Daily-streaming tactics for the rest of the week: what to do with 1, 2 or 3 streaming spots, under the real add limit.

A streaming SPOT is a roster slot given to the weakest player(s) (the "donors"): they are dropped the first time the spot is used, and from then on the
spot holds a free agent for one to three days, then is swapped again. Every add uses one of the week's adds (6 in week 1, 7 after), so several spots
cannot all be churned daily: the planner spends the adds where they raise your win chance most. It does NOT try to use every add: an add only has value on
a day your roster has an empty slot (fewer than 7 of your players have a game), which is usually two or three days a week.

Options the search considers for every remaining day:
  * a one-day streamer (any free agent whose team plays that day), including SUNDAY, which sits outside the Mon-Sat start cap and often has the most empty slots;
  * a BACK-TO-BACK hold: a free agent whose team plays on consecutive days (or twice in three days) is added once and kept, so one add covers two games;
  * players on LOW-GAME days (few teams play): your roster has the most empty slots then, and the same search scores them.
Search: greedy with a FULL re-scan at every step. Each option's gain is the change in the matchup win chance (the app's own engine: positions, 7 slots a day,
the cap, Sunday, teammates' absences, the opponent) of the whole week with the plan applied; one add per step, until the adds run out or nothing helps by at
least THRESH (0.2 points). To keep it fast, a cheap score (value x chance he plays x an empty slot that day) picks the ~30 most promising options first, plus the
best option of every day so each day gets an exact number for the day map.
Honest limits: the plan is for THIS week only (a dropped donor is gone for next week too); it assumes the free agent is available when you add him; it re-plans
from scratch at every refresh, so use today's step and let tomorrow's change with news.
"""
from datetime import timedelta

import numpy as np

import inseason_live as L

THRESH = 0.002
TOP_OPTIONS = 30


def _roster(me, donors_cut, streamers):
    """me: player dicts; donors_cut: {donor name: last day he is still on the roster}; streamers: [(player dict, t, hold)]."""
    out = []
    for p in me:
        if p["name"] in donors_cut:
            out.append({**p, "win": (0, donors_cut[p["name"]])})
        else:
            out.append(p)
    for f, t, hold in streamers:
        out.append({**f, "win": (t, t + hold - 1)})
    return out


def _assign(plan, donors):
    """Give each streamer a spot (earliest-free) and name the player he replaces. plan: [(f, t, hold)] -> (steps, donor cut days) or None if it needs more spots."""
    K = len(donors)
    free_at, occupant, first_use = [-1] * K, [d["name"] for d in donors], [None] * K
    steps = []
    for f, t, hold in sorted(plan, key=lambda x: (x[1], x[0]["name"])):
        spot = next((j for j in range(K) if free_at[j] <= t), None)
        if spot is None:
            return None
        if first_use[spot] is None:
            first_use[spot] = t
        steps.append({"f": f, "t": t, "hold": hold, "spot": spot + 1, "drops": occupant[spot]})
        occupant[spot], free_at[spot] = f["name"], t + hold
    cut = {donors[j]["name"]: first_use[j] - 1 for j in range(K) if first_use[j] is not None}
    return steps, cut


def _win_prob(me, donors, plan, wk, act, w, opp_pack):
    a = _assign(plan, donors)
    if a is None:
        return None
    _, cut = a
    ros = _roster(me, cut, [(f, t, h) for f, t, h in plan])
    pk = L.team_pack(ros, wk, act, w)
    pc, pw, t1, _ = L.matchup_eval(pk, opp_pack)
    return pw, pc, pk


def _open_slots(me, wk, act, w):
    """Empty starting slots per day with no streaming (7 minus the starters the plan already has that day)."""
    pk = L.team_pack(me, wk, act, w)
    n = {d: 0 for d in range(wk.n)}
    for _, day, _, _ in pk["plan"]["starts"]:
        n[day] += 1
    return {d: max(0, 7 - n[d]) for d in range(wk.n)}, n


def _options(fa_pl, wk, w, open_slots, pdays, per_day=10):
    """All (free agent, start day, hold) options worth scoring, with a cheap score. Hold 2-3 only if it brings a second game (back-to-back / 2 in 3 days)."""
    out = []
    for t in range(wk.today_idx, wk.n):
        for f in fa_pl:
            if f["p"] <= 0 or t not in pdays.get(f["team"], ()):
                continue
            gm = pdays.get(f["team"], ())
            for hold in (1, 2, 3):
                days = range(t, t + hold)
                if t + hold > wk.n:
                    break
                games = [d for d in days if d in gm]
                if hold > 1 and (len(games) < 2 or (t + hold - 1) not in gm):
                    continue
                if f.get("avail_from") and wk.start + timedelta(days=t) < L.date.fromisoformat(f["avail_from"]):
                    continue
                s = 0.0
                for d in games:
                    m, _ = L.absence_m(f["team"], L.norm(f["name"]), wk.start + timedelta(days=d), wk.real_today)
                    v = max(0.0, float((f["u"] * w).sum()) * f["p"] * (1 + L.ABS_KAPPA * m))
                    s += v * (1.0 if open_slots.get(d, 0) > 0 else 0.05)
                out.append((s, f, t, hold))
    out.sort(key=lambda x: -x[0])
    keep, seen_day = [], {}
    for s, f, t, h in out:                                     # top options overall, plus the best few of each day (exact numbers for the day map)
        if len(keep) < TOP_OPTIONS or seen_day.get(t, 0) < 2:
            keep.append((f, t, h))
            seen_day[t] = seen_day.get(t, 0) + 1
    return keep


def best_plan(me, opp_pack, wk, act, w, fa_pl, adds_left, K, mv, open_slots):
    pdays = wk.play_days()
    donors = sorted(me, key=lambda p: mv[p["name"]])[:K]
    base = _win_prob(me, donors, [], wk, act, w, opp_pack)
    base_pw, cur_pc = base[0], base[1]
    opts = _options(fa_pl, wk, w, open_slots, pdays)
    plan, cur_pw, gain_by, cat_by, first_gain = [], base_pw, {}, {}, {}
    used = set()
    step = 0
    while len(plan) < adds_left:
        best = None
        for i, (f, t, hold) in enumerate(opts):
            if f["name"] in used:
                continue
            res = _win_prob(me, donors, plan + [(f, t, hold)], wk, act, w, opp_pack)
            if res is None:                                            # would need more than K spots at once
                continue
            g = res[0] - cur_pw
            if step == 0:
                first_gain[(f["name"], t, hold)] = g
            if best is None or g > best[0]:
                best = (g, i, res)
        step += 1
        if best is None or best[0] < THRESH:
            break
        gain, i, res = best
        f, t, hold = opts[i]
        plan.append((f, t, hold))
        used.add(f["name"])
        gain_by[f["name"]] = gain
        cat_by[f["name"]] = res[1] - cur_pc                            # which categories this add moved
        cur_pw, cur_pc = res[0], res[1]
    a = _assign(plan, donors)
    steps, cut = a if a else ([], {})
    return {"K": K, "plan": plan, "steps": steps, "cut": cut, "donors": [d["name"] for d in donors], "pw": cur_pw, "pw_base": base_pw,
            "adds_used": len(plan), "gain_by": gain_by, "cat_by": cat_by, "first_gain": first_gain}


def marginal_values(me, opp_pack, wk, act, w, base_pw):
    mv = {}
    for p in me:
        rest = [q for q in me if q["name"] != p["name"]]
        _, pw, *_ = L.matchup_eval(L.team_pack(rest, wk, act, w), opp_pack)
        mv[p["name"]] = base_pw - pw
    return mv


def plans(me, opp_pack, wk, act, w, fa_pl, adds_left, base_pw, Ks=(1, 2, 3)):
    """Returns {K: best_plan result}, or {} when there is nothing to plan. Ks beyond the adds left are skipped (a spot needs an add)."""
    if adds_left <= 0 or wk.finished:
        return {}
    mv = marginal_values(me, opp_pack, wk, act, w, base_pw)
    open_slots, nstart = _open_slots(me, wk, act, w)
    out = {}
    for K in Ks:
        if K <= adds_left and K <= len(me) - 7:                       # keep at least 7 other players
            out[K] = best_plan(me, opp_pack, wk, act, w, fa_pl, adds_left, K, mv, open_slots)
    out["_open"], out["_nstart"] = open_slots, nstart
    return out


def day_map(sp, wk, scale):
    """One row per remaining day: NBA games, your starters, empty slots, and the best single add for that day (exact, from the first scan)."""
    res = next((v for k, v in sp.items() if isinstance(k, int)), None)
    if res is None:
        return []
    best = {}
    for (name, t, hold), g in res["first_gain"].items():
        if hold == 1 and (t not in best or g > best[t][1]):
            best[t] = (name, g)
    sch = wk.sch
    rows = []
    for t in range(wk.today_idx, wk.n):
        g = sch[sch["idx"] == t]
        if t == wk.today_idx:
            g = g[~g["started"]]
        b = best.get(t)
        rows.append({"day": t, "label": (wk.start + timedelta(days=t)).strftime("%a %m/%d"), "nba_games": int(len(g) // 2),
                     "my_starters": sp["_nstart"][t], "open": sp["_open"][t], "sunday": wk.sun is not None and t == wk.sun,
                     "best_add": b[0] if b and b[1] > 0.0005 else None, "best_gain": (b[1] * scale) if b and b[1] > 0.0005 else 0.0})
    return rows


def describe(res, wk, scale=1.0):
    """JSON-friendly steps for the page. `scale` converts raw win-chance gains to the displayed (calibrated) scale."""
    out = []
    pdays = wk.play_days()
    for s in res["steps"]:
        f = s["f"]
        gdays = [(wk.start + timedelta(days=d)).strftime("%a %m/%d") for d in range(s["t"], s["t"] + s["hold"]) if d in pdays.get(f["team"], ())]
        m, who = L.absence_m(f["team"], L.norm(f["name"]), wk.start + timedelta(days=s["t"]), wk.real_today)
        dp = res.get("cat_by", {}).get(f["name"])
        helps = [L.LABEL[c] for i, c in enumerate(L.CATS) if dp is not None and dp[i] >= 0.01]
        hurts = [L.LABEL[c] for i, c in enumerate(L.CATS) if dp is not None and dp[i] <= -0.01]
        out.append({"day": s["t"], "label": (wk.start + timedelta(days=s["t"])).strftime("%a %m/%d"), "add": f["name"], "team": f["team"],
                    "hold": s["hold"], "spot": s["spot"], "drops": s["drops"], "games": gdays, "own": f.get("own"),
                    "gain": (res.get("gain_by", {}).get(f["name"]) or 0.0) * scale, "helps": helps, "hurts": hurts,
                    "b2b": s["hold"] > 1,
                    "boost": (f"{', '.join(n for n, _ in who[:2])} out: about +{L.ABS_K[0] * m * 100:.0f}% points/usage" if m > 0.04 else None)})
    return out
