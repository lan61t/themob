"""Daily-streaming tactics for the rest of the week: what to do with 1 streaming spot vs 2 streaming spots, under the real add limit.

A streaming SPOT is a roster slot given to the weakest player(s) (the "donors"): they are dropped the first time the spot is used, and from then on the
spot holds a free agent for one or two days, then is swapped again. Every add uses one of the week's adds (6 in week 1, 7 after), so two spots
cannot both be churned daily: the planner spends the adds where they raise your win chance most.

Search: lazy greedy over options (free agent f, start day t, hold L days). Each option's gain is the change in the matchup win chance (the app's own
engine: positions, 7 slots a day, the cap, Sunday, teammates' absences, the opponent) of the whole week with the plan applied; options are re-scored
against the plan built so far, one add each, until the adds run out or nothing helps by at least `thresh`.
Honest limits: the plan is for THIS week only (a dropped donor is gone for next week too); it assumes the free agent is available when you add him;
it re-plans from scratch at every refresh, so use today's step and let tomorrow's change with news.
"""
import heapq
from datetime import timedelta

import numpy as np

import inseason_live as L

THRESH = 0.002


def _roster(me, donors_cut, streamers):
    """me: player dicts; donors_cut: {donor name: last day he is still on the roster}; streamers: [(player dict, t, hold)]."""
    out = []
    for p in me:
        if p["name"] in donors_cut:
            out.append({**p, "win": (0, donors_cut[p["name"]])})
        else:
            out.append(p)
    for f, t, hold in streamers:
        out.append({**f, "win": (t, t + hold - 1)})
    return out


def _assign(plan, donors):
    """Give each streamer a spot (earliest-free) and name the player he replaces. plan: [(f, t, hold)] -> list of dicts with spot / drops / and donor cut days."""
    K = len(donors)
    free_at, occupant, first_use = [-1] * K, [d["name"] for d in donors], [None] * K
    steps = []
    for f, t, hold in sorted(plan, key=lambda x: (x[1], x[0]["name"])):
        spot = next((j for j in range(K) if free_at[j] <= t), None)
        if spot is None:
            return None
        if first_use[spot] is None:
            first_use[spot] = t
        steps.append({"f": f, "t": t, "hold": hold, "spot": spot + 1, "drops": occupant[spot]})
        occupant[spot], free_at[spot] = f["name"], t + hold
    cut = {donors[j]["name"]: first_use[j] - 1 for j in range(K) if first_use[j] is not None}
    return steps, cut


def _win_prob(me, donors, plan, wk, act, w, opp_pack):
    a = _assign(plan, donors)
    if a is None:
        return None
    _, cut = a
    ros = _roster(me, cut, [(f, t, h) for f, t, h in plan])
    pk = L.team_pack(ros, wk, act, w)
    pc, pw, t1, _ = L.matchup_eval(pk, opp_pack)
    return pw, pc, pk


def best_plan(me, opp_pack, wk, act, w, fa_pl, adds_left, K, mv, per_day=5):
    days = list(range(wk.today_idx, wk.n))
    pdays = wk.play_days()
    donors = sorted(me, key=lambda p: mv[p["name"]])[:K]
    base_pw = _win_prob(me, donors, [], wk, act, w, opp_pack)[0]
    use_l2 = adds_left < K * len(days)
    opts = []
    for t in days:
        day = wk.start + timedelta(days=t)
        pool = []
        for f in fa_pl:
            if f["p"] <= 0 or t not in pdays.get(f["team"], ()):
                continue
            if f.get("avail_from") and day < L.date.fromisoformat(f["avail_from"]):
                continue
            m, _ = L.absence_m(f["team"], L.norm(f["name"]), day, wk.real_today)
            pool.append((float((f["u"] * w).sum()) * f["p"] * (1 + L.ABS_KAPPA * m), f))
        for _, f in sorted(pool, key=lambda x: -x[0])[:per_day]:
            for hold in ((1, 2) if use_l2 and t + 1 < wk.n else (1,)):
                opts.append((f, t, hold))
    plan, cur_pw = [], base_pw
    heap = [(-1.0, i) for i in range(len(opts))]                      # stale gains start optimistic; re-scored lazily
    heapq.heapify(heap)
    used = set()
    while heap and len(plan) < adds_left:
        neg, i = heapq.heappop(heap)
        f, t, hold = opts[i]
        if f["name"] in used:
            continue
        res = _win_prob(me, donors, plan + [(f, t, hold)], wk, act, w, opp_pack)
        if res is None:                                                # would need more than K spots at once
            continue
        gain = res[0] - cur_pw
        if heap and gain < -heap[0][0] - 1e-12:                         # someone else may now be better: put back with the true gain
            heapq.heappush(heap, (-gain, i))
            continue
        if gain < THRESH:
            break
        plan.append((f, t, hold))
        used.add(f["name"])
        cur_pw = res[0]
    a = _assign(plan, donors)
    steps, cut = a if a else ([], {})
    return {"K": K, "plan": plan, "steps": steps, "cut": cut, "donors": [d["name"] for d in donors], "pw": cur_pw, "pw_base": base_pw,
            "adds_used": len(plan)}


def marginal_values(me, opp_pack, wk, act, w, base_pw):
    mv = {}
    for p in me:
        rest = [q for q in me if q["name"] != p["name"]]
        _, pw, *_ = L.matchup_eval(L.team_pack(rest, wk, act, w), opp_pack)
        mv[p["name"]] = base_pw - pw
    return mv


def plans(me, opp_pack, wk, act, w, fa_pl, adds_left, base_pw, Ks=(1, 2)):
    """Returns {K: best_plan result} for each number of streaming spots, or {} when there is nothing to plan."""
    if adds_left <= 0 or wk.finished:
        return {}
    mv = marginal_values(me, opp_pack, wk, act, w, base_pw)
    return {K: best_plan(me, opp_pack, wk, act, w, fa_pl, adds_left, K, mv) for K in Ks}


def describe(res, wk):
    """JSON-friendly steps for the page."""
    out = []
    pdays = wk.play_days()
    for s in res["steps"]:
        f = s["f"]
        gdays = [(wk.start + timedelta(days=d)).strftime("%a %m/%d") for d in range(s["t"], s["t"] + s["hold"]) if d in pdays.get(f["team"], ())]
        m, who = L.absence_m(f["team"], L.norm(f["name"]), wk.start + timedelta(days=s["t"]), wk.real_today)
        out.append({"day": s["t"], "label": (wk.start + timedelta(days=s["t"])).strftime("%a %m/%d"), "add": f["name"], "team": f["team"],
                    "hold": s["hold"], "spot": s["spot"], "drops": s["drops"], "games": gdays, "own": f.get("own"),
                    "boost": (f"{', '.join(n for n, _ in who[:2])} out: about +{L.ABS_K[0] * m * 100:.0f}% points/usage" if m > 0.04 else None)})
    return out
