"""Daily-streaming tactics for the rest of the week: what to do with 1, 2 or 3 streaming spots, under the real add limit.

A streaming SPOT is a roster slot given to the weakest player(s) (the "donors"): they are dropped the first time the spot is used, and from then on the
spot holds a free agent for one to three days, then is swapped again. Every add uses one of the week's adds (6 in week 1, 7 after), so several spots
cannot all be churned daily: the planner spends the adds where they raise your win chance most. It does NOT try to use every add: an add only has value on
a day your roster has an empty slot (fewer than 7 of your players have a game), which is usually two or three days a week.

Options the search considers for every remaining day:
  * a one-day streamer (any free agent whose team plays that day), including SUNDAY, which sits outside the Mon-Sat start cap and often has the most empty slots;
  * a BACK-TO-BACK hold: a free agent whose team plays on consecutive days (or twice in three days) is added once and kept, so one add covers two games;
  * players on LOW-GAME days (few teams play): your roster has the most empty slots then, and the same search scores them.
Search: greedy with a FULL re-scan at every step. Each option's gain is the change in the matchup win chance (the app's own engine: positions, 7 slots a day,
the cap, Sunday, teammates' absences, the opponent) of the whole week with the plan applied; one add per step, until the adds run out or nothing helps by at
least THRESH (0.2 points). To keep it fast, a cheap score (value x chance he plays x an empty slot that day) picks the ~30 most promising options first, plus the
best option of every day so each day gets an exact number for the day map.
Honest limits: the plan is for THIS week only (a dropped donor is gone for next week too); it assumes the free agent is available when you add him; it re-plans
from scratch at every refresh, so use today's step and let tomorrow's change with news.
"""
from datetime import timedelta

import numpy as np

import inseason_live as L

THRESH = 0.002
TOP_OPTIONS = 30


def _roster(me, donors_cut, streamers):
    """me: player dicts; donors_cut: {donor name: last day he is still on the roster}; streamers: [(player dict, t, hold)]."""
    out = []
    for p in me:
        if p["name"] in donors_cut:
            out.append({**p, "win": (0, donors_cut[p["name"]])})
        else:
            out.append(p)
    for f, t, hold in streamers:
        out.append({**f, "win": (t, t + hold - 1)})
    return out


def _assign(plan, donors):
    """Give each streamer a spot (earliest-free) and name the player he replaces. plan: [(f, t, hold)] -> (steps, donor cut days) or None if it needs more spots."""
    K = len(donors)
    free_at, occupant, first_use = [-1] * K, [d["name"] for d in donors], [None] * K
    steps = []
    for f, t, hold in sorted(plan, key=lambda x: (x[1], x[0]["name"])):
        spot = next((j for j in range(K) if free_at[j] <= t), None)
        if spot is None:
            return None
        if first_use[spot] is None:
            first_use[spot] = t
        steps.append({"f": f, "t": t, "hold": hold, "spot": spot + 1, "drops": occupant[spot]})
        occupant[spot], free_at[spot] = f["name"], t + hold
    cut = {donors[j]["name"]: first_use[j] - 1 for j in range(K) if first_use[j] is not None}
    return steps, cut


def _win_prob(me, donors, plan, wk, act, w, opp_pack):
    a = _assign(plan, donors)
    if a is None:
        return None
    _, cut = a
    ros = _roster(me, cut, [(f, t, h) for f, t, h in plan])
    pk = L.team_pack(ros, wk, act, w)
    pc, pw, t1, _ = L.matchup_eval(pk, opp_pack)
    return pw, pc, pk


def _open_slots(me, wk, act, w):
    """Empty starting slots per day with no streaming (7 minus the starters the plan already has that day)."""
    pk = L.team_pack(me, wk, act, w)
    n = {d: 0 for d in range(wk.n)}
    for _, day, _, _ in pk["plan"]["starts"]:
        n[day] += 1
    return {d: max(0, len(L.A.SLOTS) - n[d]) for d in range(wk.n)}, n


def _options(fa_pl, wk, w, open_slots, pdays, per_day=10):
    """All (free agent, start day, hold) options worth scoring, with a cheap score. Hold 2-3 only if it brings a second game (back-to-back / 2 in 3 days)."""
    out = []
    for t in range(wk.today_idx, wk.n):
        for f in fa_pl:
            if f["p"] <= 0 or t not in pdays.get(f["team"], ()):
                continue
            gm = sorted(d for d in pdays.get(f["team"], ()) if d >= t)
            if f.get("avail_from") and wk.start + timedelta(days=t) < L.date.fromisoformat(f["avail_from"]):
                continue
            for e in gm:                                           # hold from day t to ANY of his later game days (up to the end of the week): one add, several games
                hold = e - t + 1
                games = [d for d in gm if d <= e]
                s = 0.0
                for d in games:
                    m, _ = L.absence_m(f["team"], L.norm(f["name"]), wk.start + timedelta(days=d), wk.real_today)
                    v = max(0.0, float((f["u"] * w).sum()) * f["p"] * (1 + L.ABS_KAPPA * m))
                    s += v * (1.0 if open_slots.get(d, 0) > 0 else 0.05)
                out.append((s, f, t, hold))
    out.sort(key=lambda x: -x[0])
    keep, seen = [], {}
    bucket = lambda h: 0 if h == 1 else (1 if h <= 3 else 2)
    for s, f, t, h in out:                                     # top options overall, plus the best two of each (day, hold length) group: short, medium, long
        k = (t, bucket(h))
        if len(keep) < TOP_OPTIONS or seen.get(k, 0) < 3:
            keep.append((f, t, h))
            seen[k] = seen.get(k, 0) + 1
    return keep


PROTECT_CATS = ("to", "fg_pct", "3p_pct", "pf")     # categories extra players tend to hurt
PROTECT_MIN, PROTECT_FLOOR, PROTECT_MAX_DROP = 0.60, 0.55, 0.07


def make_guard(me, opp_pack, wk, act, w):
    """'Protect' rule: a category among TO / FG% / 3P% / PF that you currently lead at >= 60% may not fall below 55% or lose more than 7 points of win chance
    in a plan. Returns {'items': [(category index, floor)], 'labels': [...], 'floors': {label: floor}}; items is empty when none of them is a lead."""
    pc0 = L.matchup_eval(L.team_pack(me, wk, act, w), opp_pack)[0]
    items, labels, floors = [], [], {}
    for c in PROTECT_CATS:
        i = L.CATS.index(c)
        if pc0[i] >= PROTECT_MIN:
            fl = max(PROTECT_FLOOR, float(pc0[i]) - PROTECT_MAX_DROP)
            items.append((i, fl)); labels.append(L.LABEL[c]); floors[L.LABEL[c]] = fl
    return {"items": items, "labels": labels, "floors": floors}


def best_plan(me, opp_pack, wk, act, w, fa_pl, adds_left, K, mv, open_slots, guard=None):
    pdays = wk.play_days()
    donors = sorted(me, key=lambda p: mv[p["name"]])[:K]
    base = _win_prob(me, donors, [], wk, act, w, opp_pack)
    base_pw, base_pc = base[0], base[1]
    opts = _options(fa_pl, wk, w, open_slots, pdays)
    first_gain = {}

    def run(forced, init=(), maxhold=99):
        """Greedy with a full re-scan each step (the first add also pays for dropping the donor, so later adds can be worth MORE than they looked
        at the start). `forced` = index of the option to take first (None = the best first pick); `init` = option indexes to start from."""
        plan, cur_pw, cur_pc, gain_by, cat_by, used, step = [], base_pw, base_pc, {}, {}, set(), 0
        ok = lambda res: not guard or all(res[1][gi] >= fl - 1e-9 for gi, fl in guard)      # protected categories must stay above their floors
        for i in init:                                                 # start from a seed plan, adding its options one by one (gives each its marginal gain)
            f, t, hold = opts[i]
            res = _win_prob(me, donors, plan + [(f, t, hold)], wk, act, w, opp_pack)
            if res is None or f["name"] in used or not ok(res):
                continue
            plan.append((f, t, hold)); used.add(f["name"])
            gain_by[f["name"]], cat_by[f["name"]] = res[0] - cur_pw, res[1] - cur_pc
            cur_pw, cur_pc = res[0], res[1]
        step = 1 if init else 0
        while len(plan) < adds_left:
            best = None
            for i, (f, t, hold) in enumerate(opts):
                if f["name"] in used or hold > maxhold or (step == 0 and forced is not None and i != forced):
                    continue
                res = _win_prob(me, donors, plan + [(f, t, hold)], wk, act, w, opp_pack)
                if res is None or not ok(res):                         # needs more than K spots at once, or breaks a protected category
                    continue
                g = res[0] - cur_pw
                if step == 0 and forced is None:
                    first_gain[(f["name"], t, hold)] = g
                if best is None or g > best[0]:
                    best = (g, i, res)
            step += 1
            if best is None or (best[0] < THRESH and not (step == 1 and forced is not None)):
                break
            gain, i, res = best
            f, t, hold = opts[i]
            plan.append((f, t, hold))
            used.add(f["name"])
            gain_by[f["name"]] = gain
            cat_by[f["name"]] = res[1] - cur_pc                        # which categories this add moved
            cur_pw, cur_pc = res[0], res[1]
        return {"plan": plan, "pw": cur_pw, "gain_by": gain_by, "cat_by": cat_by}

    best_run = run(None)
    # Multi-start: a greedy plan can be trapped by its first pick (e.g. one long hold that blocks a better two-add combination), so also try the
    # next-best first picks (different players) and keep whichever whole plan ends with the highest win chance.
    fg = lambda i: first_gain.get((opts[i][0]["name"], opts[i][1], opts[i][2]), -9)
    tried = {best_run["plan"][0][0]["name"]} if best_run["plan"] else set()
    for i in sorted(range(len(opts)), key=lambda i: -fg(i)):
        if len(tried) >= 3 or fg(i) < THRESH:
            break
        if opts[i][0]["name"] in tried:
            continue
        tried.add(opts[i][0]["name"])
        r2 = run(i)
        if r2["pw"] > best_run["pw"] + 1e-9:
            best_run = r2
    # Seed from a combinatorial search on the standalone gains: choose non-overlapping windows (at most K at once, one add per player) that maximise the
    # summed gain, then let the full greedy extend it. Catches combinations a greedy first pick walks past (e.g. Braun Thu + McBride Sun vs McCain alone).
    cand = sorted(((fg(i), i) for i in range(len(opts)) if fg(i) >= THRESH), reverse=True)
    seed, nodes = [], [0]
    if K == 1:
        best_seed = [0.0, []]

        def dfs(day, used, total, chosen):
            nodes[0] += 1
            if total > best_seed[0]:
                best_seed[0], best_seed[1] = total, list(chosen)
            if len(chosen) >= adds_left or nodes[0] > 60000:
                return
            for g, i in cand:
                f, t, h = opts[i]
                if t < day or f["name"] in used:
                    continue
                chosen.append(i); used.add(f["name"])
                dfs(t + h, used, total + g, chosen)
                chosen.pop(); used.discard(f["name"])
        dfs(0, set(), 0.0, [])
        seed = best_seed[1]
    else:
        load, used = [0] * wk.n, set()
        for g, i in cand:
            f, t, h = opts[i]
            if f["name"] in used or len(seed) >= adds_left or any(load[d] >= K for d in range(t, t + h)):
                continue
            seed.append(i); used.add(f["name"])
            for d in range(t, t + h):
                load[d] += 1
    if seed:
        r3 = run(None, init=seed)
        if r3["pw"] > best_run["pw"] + 1e-9:
            best_run = r3
    # Short holds only: a long hold taken first can block a better set of short streamers on the same spot, so this restricted greedy is a candidate too.
    for mh in (1, 3):
        r4 = run(None, maxhold=mh)
        if r4["pw"] > best_run["pw"] + 1e-9:
            best_run = r4
    plan = best_run["plan"]
    a = _assign(plan, donors)
    steps, cut = a if a else ([], {})
    return {"K": K, "plan": plan, "steps": steps, "cut": cut, "donors": [d["name"] for d in donors], "pw": best_run["pw"], "pw_base": base_pw,
            "adds_used": len(plan), "gain_by": best_run["gain_by"], "cat_by": best_run["cat_by"], "first_gain": first_gain, "opts": opts}


def marginal_values(me, opp_pack, wk, act, w, base_pw):
    mv = {}
    for p in me:
        rest = [q for q in me if q["name"] != p["name"]]
        _, pw, *_ = L.matchup_eval(L.team_pack(rest, wk, act, w), opp_pack)
        mv[p["name"]] = base_pw - pw
    return mv


def plans(me, opp_pack, wk, act, w, fa_pl, adds_left, base_pw, Ks=(1, 2, 3), guard=None):
    """Returns {K: best_plan result}, or {} when there is nothing to plan. Ks beyond the adds left are skipped (a spot needs an add).
    guard = make_guard(...)['items'] for the 'protect' variant."""
    if adds_left <= 0 or wk.finished:
        return {}
    mv = marginal_values(me, opp_pack, wk, act, w, base_pw)
    open_slots, nstart = _open_slots(me, wk, act, w)
    out = {}
    for K in Ks:
        if K <= adds_left and K <= len(me) - 7:                       # keep at least 7 other players
            out[K] = best_plan(me, opp_pack, wk, act, w, fa_pl, adds_left, K, mv, open_slots, guard=guard)
    out["_open"], out["_nstart"] = open_slots, nstart
    return out


def best_single(sp, wk, scale):
    """The single best add (one add, any hold length), from the first scan of the 1-spot search: what to do if you only want to spend ONE add."""
    res = next((v for k, v in sp.items() if isinstance(k, int)), None)
    if res is None or not res["first_gain"]:
        return None
    (name, t, hold), g = max(res["first_gain"].items(), key=lambda kv: kv[1])
    if g < THRESH:
        return None
    f = next((o[0] for o in res["opts"] if o[0]["name"] == name), None)
    pdays = wk.play_days()
    gdays = [(wk.start + timedelta(days=d)).strftime("%a") for d in range(t, t + hold) if d in pdays.get(f["team"], ())] if f else []
    return {"add": name, "team": f["team"] if f else "", "start": (wk.start + timedelta(days=t)).strftime("%a %m/%d"), "day": t, "hold": hold,
            "games": gdays, "gain": g * scale, "donor": res["donors"][0] if res["donors"] else None,
            "_f": f, "_t": t, "_hold": hold, "_cut": {res["donors"][0]: t - 1} if res["donors"] else {}}


def day_map(sp, wk, scale):
    """One row per remaining day: NBA games, your starters, empty slots, and the best single add for that day (exact, from the first scan)."""
    res = next((v for k, v in sp.items() if isinstance(k, int)), None)
    if res is None:
        return []
    best = {}
    for (name, t, hold), g in res["first_gain"].items():
        if hold == 1 and (t not in best or g > best[t][1]):
            best[t] = (name, g)
    sch = wk.sch
    rows = []
    for t in range(wk.today_idx, wk.n):
        g = sch[sch["idx"] == t]
        if t == wk.today_idx:
            g = g[~g["started"]]
        b = best.get(t)
        rows.append({"day": t, "label": (wk.start + timedelta(days=t)).strftime("%a %m/%d"), "nba_games": int(len(g) // 2),
                     "my_starters": sp["_nstart"][t], "open": sp["_open"][t], "sunday": wk.sun is not None and t == wk.sun,
                     "best_add": b[0] if b and b[1] > 0.0005 else None, "best_gain": (b[1] * scale) if b and b[1] > 0.0005 else 0.0})
    return rows


def describe(res, wk, scale=1.0):
    """JSON-friendly steps for the page. `scale` converts raw win-chance gains to the displayed (calibrated) scale."""
    out = []
    pdays = wk.play_days()
    for s in res["steps"]:
        f = s["f"]
        gdays = [(wk.start + timedelta(days=d)).strftime("%a %m/%d") for d in range(s["t"], s["t"] + s["hold"]) if d in pdays.get(f["team"], ())]
        m, who = L.absence_m(f["team"], L.norm(f["name"]), wk.start + timedelta(days=s["t"]), wk.real_today)
        dp = res.get("cat_by", {}).get(f["name"])
        helps = [L.LABEL[c] for i, c in enumerate(L.CATS) if dp is not None and dp[i] >= 0.01]
        hurts = [L.LABEL[c] for i, c in enumerate(L.CATS) if dp is not None and dp[i] <= -0.01]
        out.append({"day": s["t"], "label": (wk.start + timedelta(days=s["t"])).strftime("%a %m/%d"), "add": f["name"], "team": f["team"],
                    "hold": s["hold"], "spot": s["spot"], "drops": s["drops"], "games": gdays, "own": f.get("own"),
                    "gain": (res.get("gain_by", {}).get(f["name"]) or 0.0) * scale, "helps": helps, "hurts": hurts,
                    "b2b": s["hold"] > 1,
                    "boost": (f"{', '.join(n for n, _ in who[:2])} out: about +{L.ABS_K[0] * m * 100:.0f}% points/usage" if m > 0.04 else None)})
    return out
