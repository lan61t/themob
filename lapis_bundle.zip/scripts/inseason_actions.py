"""'Today's actions': the few things worth doing now, each with a deadline, derived from the finished state dict.

Priorities: 1 = do it before the next tip, 2 = worth doing today, 3 = good to know. Rules (all thresholds stated, none hidden):
  LINEUP  your ESPN lineup for the next game day differs from the recommended one -> the START / BENCH changes, deadline = the first
          tip among the players involved (lineups lock per game)
  ALERT   a player on your roster changed injury status -> check the replacement; priority 1 if he is in the next lineup
  STREAM  the best swap raises your win chance by >= 1.0 point and you still have adds -> add X / drop Y with what it helps and costs
  CAP     you are within 3 starts of the Mon-Sat cap with Sunday still open -> every start past the cap costs Sunday
  OPP     the opponent changed their roster -> what they did
  none    nothing clears the bar -> an explicit "no action needed", so silence is never ambiguous
"""
from datetime import datetime


def _earliest(tips):
    t = [x for x in tips if x]
    return min(t) if t else None


def build_actions(st):
    acts = []
    w, lus = st["week"], st["lineups"]
    nxt = lus[0] if lus else None
    # 1. lineup
    if nxt and nxt.get("vs_espn") and nxt["changes"]:
        tips = {s["name"]: s.get("tip") for s in nxt["start"]}
        tips.update({s["name"]: s.get("tip") for s in nxt["sits"]})
        starts = [c["name"] for c in nxt["changes"] if c["move"] == "START"]
        bench = [c["name"] for c in nxt["changes"] if c["move"] == "BENCH"]
        acts.append({"prio": 1, "kind": "LINEUP", "title": f"Set your lineup for {nxt['label']}",
                     "detail": ("Start " + ", ".join(starts) if starts else "") + ("; " if starts and bench else "") + ("bench " + ", ".join(bench) if bench else ""),
                     "deadline": _earliest([tips.get(n) for n in starts + bench])})
    # 2. injury alerts on my roster
    in_next = {s["name"] for s in nxt["start"]} if nxt else set()
    for a in st.get("alerts", []):
        if a["where"] != "you":
            continue
        prio = 1 if a["name"] in in_next else 2
        ret = f", back {a['ret']}" if a.get("ret") else ""
        acts.append({"prio": prio, "kind": "ALERT", "title": f"{a['name']}: {a['old'].replace('_', ' ').title()} to {a['new'].replace('_', ' ').title()}{ret}",
                     "detail": (a.get("comment") or a.get("detail") or "") + (" He is in your next lineup: check the swap list." if prio == 1 else ""),
                     "deadline": None})
    # 3. best streaming swap
    top = st["streaming"][0] if st.get("streaming") else None
    if top and w["adds_left"] > 0 and top["d_pwin"] >= 0.01:
        helps = ", ".join(e["cat"] for e in top["helps"][:3]) or "-"
        hurts = ", ".join(e["cat"] for e in top["hurts"][:2]) or "nothing notable"
        wait = f" He is on waivers until {top['add_wait']}." if top.get("add_wait") else ""
        acts.append({"prio": 2, "kind": "STREAM", "title": f"Add {top['add']}, drop {top['drop']}",
                     "detail": f"+{top['d_pwin'] * 100:.1f} pts win chance. Helps {helps}; costs {hurts}. {top['games_left']} games left this week.{wait}",
                     "deadline": None})
    # 4. cap watch
    if w["sunday"] == "open" and w["cap"] - 3 <= w["gp_me"] <= w["cap"]:
        acts.append({"prio": 2, "kind": "CAP", "title": f"{w['gp_me']:.0f} of {w['cap']} starts used",
                     "detail": "Each start past the cap still counts but locks Sunday. Stay at or under it unless Sunday has almost nothing for you.", "deadline": None})
    # 5. opponent moves
    opp_id = next((t["id"] for t in st["league"]["teams"] if t["is_opp"]), None)
    for m in st["league"]["moves"][:5]:
        if m["team_id"] == opp_id and m["ts"] == st["asof"]:
            acts.append({"prio": 3, "kind": "OPP", "title": f"{st['opp']['name']} changed their roster",
                         "detail": ("Added " + ", ".join(m["in"]) if m["in"] else "") + ("; dropped " + ", ".join(m["out"]) if m["out"] else ""), "deadline": None})
    if not acts:
        acts.append({"prio": 3, "kind": "NONE", "title": "No action needed right now",
                     "detail": "Your lineup matches the recommendation, no one on your roster changed status, and no swap raises your win chance by a point.",
                     "deadline": None})
    acts.sort(key=lambda a: (a["prio"], a["deadline"] or "9"))
    return acts
