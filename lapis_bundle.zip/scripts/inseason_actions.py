"""'Today's actions': the few things worth doing now, each with a deadline, derived from the finished state dict.

Priorities: 1 = do it before the next tip, 2 = worth doing today, 3 = good to know. Rules (all thresholds stated, none hidden):
  LINEUP  your ESPN lineup for the next game day differs from the recommended one -> the START / BENCH changes, deadline = the first
          tip among the players involved (lineups lock per game)
  ALERT   a player on your roster changed injury status -> check the replacement; priority 1 if he is in the next lineup
  FA      a free agent rated MUST pick up (inseason_fa.py): claim him, drop the named player
  STREAM  the 1-spot streaming plan from the tactic planner (the same one the page shows), its best single add and the 2/3-spot totals; if the planner
          found nothing, the best single swap when it raises your win chance by >= 1.0 point
  CAP     you are within 3 starts of the Mon-Sat cap with Sunday still open -> every start past the cap costs Sunday
  OPP     the opponent changed their roster -> what they did
  none    nothing clears the bar -> an explicit "no action needed", so silence is never ambiguous
"""
from datetime import datetime


def _earliest(tips):
    t = [x for x in tips if x]
    return min(t) if t else None


def build_actions(st):
    acts = []
    w, lus = st["week"], st["lineups"]
    nxt = lus[0] if lus else None
    # 1. lineup
    if nxt and nxt.get("vs_espn") and nxt["changes"]:
        tips = {s["name"]: s.get("tip") for s in nxt["start"]}
        tips.update({s["name"]: s.get("tip") for s in nxt["sits"]})
        starts = [c["name"] for c in nxt["changes"] if c["move"] == "START"]
        bench = [c["name"] for c in nxt["changes"] if c["move"] == "BENCH"]
        acts.append({"prio": 1, "kind": "LINEUP", "title": f"Set your lineup for {nxt['label']}",
                     "detail": ("Start " + ", ".join(starts) if starts else "") + ("; " if starts and bench else "") + ("bench " + ", ".join(bench) if bench else ""),
                     "deadline": _earliest([tips.get(n) for n in starts + bench])})
    # 2. injury alerts on my roster
    in_next = {s["name"] for s in nxt["start"]} if nxt else set()
    for a in st.get("alerts", []):
        if a["where"] != "you":
            continue
        prio = 1 if a["name"] in in_next else 2
        ret = f", back {a['ret']}" if a.get("ret") else ""
        acts.append({"prio": prio, "kind": "ALERT", "title": f"{a['name']}: {a['old'].replace('_', ' ').title()} to {a['new'].replace('_', ' ').title()}{ret}",
                     "detail": (a.get("comment") or a.get("detail") or "") + (" He is in your next lineup: check the swap list." if prio == 1 else ""),
                     "deadline": None})
    # 3. streaming: ONE recommendation, taken from the same tactic planner the page shows (so the two can never disagree)
    sp = st.get("stream_plans") or {}
    plans = {p["K"]: p for p in sp.get("plans", []) if p.get("steps")}
    single = sp.get("single")
    if plans and w["adds_left"] > 0:
        p1 = plans.get(1) or next(iter(plans.values()))
        first = p1["steps"][0]
        today_idx = w.get("today_idx", 0)
        is_now = first["day"] <= today_idx
        move = "; then ".join(f"{s['label'].split(' ')[0]} add {s['add']} (drop {s['drops']})" for s in p1["steps"])
        alt = (f" One add only: {single['add']} on {single['start'].split(' ')[0]}"
               f"{', kept ' + str(single['hold']) + ' days' if single['hold'] > 1 else ''} (+{single['gain'] * 100:.1f} pts)." if single else "")
        more = " ".join(f"{p['K']} spots: +{p['gain'] * 100:.1f} pts with {p['adds_used']} adds." for k, p in plans.items() if k > 1)
        acts.append({"prio": 1 if is_now else 2, "kind": "STREAM",
                     "title": ("Stream now: " if is_now else "Streaming plan: ") + move,
                     "detail": f"1 spot, {p1['adds_used']} of {w['adds_left']} adds, +{p1['gain'] * 100:.1f} pts win chance.{alt} {more} Details and the days with empty slots are in the Streaming tactic card.",
                     "deadline": None})
    elif st.get("streaming") and w["adds_left"] > 0 and st["streaming"][0]["d_pwin"] >= 0.01:      # no tactic plan: fall back to the best single swap
        top = st["streaming"][0]
        acts.append({"prio": 2, "kind": "STREAM", "title": f"Add {top['add']}, drop {top['drop']}",
                     "detail": f"+{top['d_pwin'] * 100:.1f} pts win chance, {top['games_left']} games left this week.", "deadline": None})
    # 3b. free agents: a MUST pick up is worth a line of its own
    fa = (st.get("fa") or {}).get("rows", [])
    for r in [y for y in fa if y["tier"] == "MUST"][:2]:
        acts.append({"prio": 2, "kind": "FA", "title": f"Claim {r['name']} (drop {r['drop']})",
                     "detail": f"Must pick up: team value {r['gain']:+.2f}. " + (r["why"][1] if len(r["why"]) > 1 else (r["why"][0] if r["why"] else "")) + " Waiver claims process Sunday.",
                     "deadline": None})
    # 4. cap watch
    if w["sunday"] == "open" and w["cap"] - 3 <= w["gp_me"] <= w["cap"]:
        acts.append({"prio": 2, "kind": "CAP", "title": f"{w['gp_me']:.0f} of {w['cap']} starts used",
                     "detail": "Each start past the cap still counts but locks Sunday. Stay at or under it unless Sunday has almost nothing for you.", "deadline": None})
    # 5. opponent moves
    opp_id = next((t["id"] for t in st["league"]["teams"] if t["is_opp"]), None)
    for m in st["league"]["moves"][:5]:
        if m["team_id"] == opp_id and m["ts"] == st["asof"]:
            acts.append({"prio": 3, "kind": "OPP", "title": f"{st['opp']['name']} changed their roster",
                         "detail": ("Added " + ", ".join(m["in"]) if m["in"] else "") + ("; dropped " + ", ".join(m["out"]) if m["out"] else ""), "deadline": None})
    if not acts:
        acts.append({"prio": 3, "kind": "NONE", "title": "No action needed right now",
                     "detail": "Your lineup matches the recommendation, no one on your roster changed status, and no swap raises your win chance by a point.",
                     "deadline": None})
    acts.sort(key=lambda a: (a["prio"], a["deadline"] or "9"))
    return acts
