// Trade tab: find the best partner for players you want to send, or type in any trade and get the full analysis.
// Uses TL (tradelab_engine.js) in the browser; on the local server it asks /api/trade_eval and /api/trade_search for the exact engine.
// Inlined into lapis_app_template.html (placeholder /*TL_UI*/); relies on the page helpers $, esc, pct1, sg, S, MODE, getJSON.
let TR={give:[],partner:null,send:[],recv:[],res:null,finder:null,fmsg:'',amsg:'',busy:false,fbusy:false};
const TL_POS=a=>(a||[]).join('/');
function tlGames(LB,n){const P=LB.players[n];if(!P)return {g:0,e:0};let g=0,e=0;P.p.forEach(w=>w.forEach(x=>{if(x>0){g++;e+=x}}));return {g,e}}
function tlChip(LB,n,on,act){const P=LB.players[n]||{};const inj=P.inj&&P.inj!=='ACTIVE'?` <span class="tag t-WATCH">${esc(String(P.inj).replace('DAY_TO_DAY','DTD').replace('INJURY_RESERVE','IR'))}</span>`:'';
  return `<button class="chipbtn ${on?'on':''}" data-tl="${act}" data-n="${esc(n)}">${esc(n)} <small style="opacity:.75">${esc(P.team||'')} ${esc(TL_POS(P.elig))}</small>${inj}</button>`}
function tlVerdictText(r){
  const dm=r.d_me*100,dt=r.d_them*100;
  const t={'WIN-WIN':`Both teams gain in the model, so this is an easy offer to make.`,
    'FAIR':`You gain and they lose almost nothing (${dt.toFixed(1)} pts), so it is likely acceptable. ESPN needs 8 veto votes to block a trade.`,
    'ONE-SIDED':`You gain, but their power falls ${Math.abs(dt).toFixed(1)} pts: expect a counter-offer or a no. Ask what you could add to make it work for them.`,
    'FAVOURS THEM':`This helps them more than you (you ${sg(r.d_me)} pts, they ${sg(r.d_them)}). Only do it if you need the category fit.`,
    'NO':`This lowers your power in the model (${sg(r.d_me)} pts). Not recommended.`}[r.verdict];
  return t||''}
function tlWhy(LB,r){
  const out=[];
  const up=r.me_cat.filter(c=>c.p1-c.p0>=0.01).sort((a,b)=>(b.p1-b.p0)-(a.p1-a.p0)).slice(0,4).map(c=>`${esc(c.cat)} ${sg(c.p1-c.p0,0)}`);
  const dn=r.me_cat.filter(c=>c.p1-c.p0<=-0.01).sort((a,b)=>(a.p1-a.p0)-(b.p1-b.p0)).slice(0,4).map(c=>`${esc(c.cat)} ${sg(c.p1-c.p0,0)}`);
  if(up.length)out.push(`<span class="pos">You gain:</span> ${up.join(', ')} (points of weekly win chance per category).`);
  if(dn.length)out.push(`<span class="neg">You lose:</span> ${dn.join(', ')}.`);
  if(!up.length&&!dn.length)out.push('No category moves by more than a point for you.');
  if(r.give.length>r.get.length)out.push(`<b>${r.give.length}-for-${r.get.length}:</b> you send more bodies than you get${r.fill_me.length?`, so you add ${esc(r.fill_me.join(', '))} from free agents`:''}${r.drop_me.length?` and drop ${esc(r.drop_me.join(', '))}`:''}. Starts are scarce, so the best player in the deal matters more than the count.`);
  if(r.get.length>r.give.length)out.push(`<b>${r.give.length}-for-${r.get.length}:</b> you get more bodies than you send${r.drop_me.length?`, so you must drop ${esc(r.drop_me.join(', '))}`:''}${r.fill_me.length?`, then add ${esc(r.fill_me.join(', '))}`:''}.`);
  r.get_info.forEach(p=>{const i=String(p.inj||'ACTIVE');const g=tlGames(LB,p.name);
    if(i!=='ACTIVE')out.push(`<b>${esc(p.name)}</b> is ${esc(i.replace('_',' '))}: expected availability ${Math.round(p.avail*100)}%, about ${g.e.toFixed(1)} games in the next ${LB.weeks.length} weeks.`)});
  r.give_info.forEach(p=>{const i=String(p.inj||'ACTIVE');if(i!=='ACTIVE')out.push(`<b>${esc(p.name)}</b> (yours) is ${esc(i.replace('_',' '))}: the other manager may discount him.`)});
  out.push(r.d_them>=0.002?`They gain ${sg(r.d_them)} pts, so a rational manager says yes.`:r.d_them>=-0.002?`For them it is roughly neutral (${sg(r.d_them)} pts).`:`They lose ${Math.abs(r.d_them*100).toFixed(1)} pts of power, so they have a reason to say no.`);
  if(r.drop_them.length||r.fill_them.length)out.push(`They would ${r.drop_them.length?'drop '+esc(r.drop_them.join(', ')):''}${r.drop_them.length&&r.fill_them.length?' and ':''}${r.fill_them.length?'add '+esc(r.fill_them.join(', ')):''} to stay at their roster size.`);
  return out}
function tlPlayers(LB,r){
  const row=(p,tagc,lab)=>{const g=tlGames(LB,p.name),pg=p.pg||{};const fg=pg.fga?pg.fgm/pg.fga:0;
    return `<tr><td><span class="tag ${tagc}">${lab}</span> <b>${esc(p.name)}</b><div class="muted" style="font-size:12px">${esc(p.team)} ${esc(TL_POS(p.elig))}${p.inj&&p.inj!=='ACTIVE'?' · '+esc(String(p.inj).replace('_',' ')):''}</div></td>
      <td>${(pg.pts||0).toFixed(1)}</td><td>${((pg.oreb||0)+(pg.dreb||0)).toFixed(1)}</td><td>${(pg.ast||0).toFixed(1)}</td><td>${(pg.stl||0).toFixed(1)}/${(pg.blk||0).toFixed(1)}</td><td>${(pg['3pm']||0).toFixed(1)}</td><td>${(fg*100).toFixed(0)}%</td><td>${(pg.to||0).toFixed(1)}</td>
      <td>${g.e.toFixed(1)}<span class="muted"> / ${g.g}</span></td><td class="${p.eff>=0?'pos':'neg'}">${p.eff>=0?'+':''}${p.eff.toFixed(2)}</td></tr>`};
  return `<div class="tscroll"><table class="tl-tab"><thead><tr><th>Player</th><th>PTS</th><th>REB</th><th>AST</th><th>STL/BLK</th><th>3PM</th><th>FG%</th><th>TO</th><th title="expected games / scheduled games over the weeks analysed">GP</th><th title="value to your team: depth-weighted G-score per game, tilted to your weak categories">Value</th></tr></thead>
    <tbody>${r.give_info.map(p=>row(p,'t-concede','SEND')).join('')}${r.get_info.map(p=>row(p,'t-lean','GET')).join('')}</tbody></table></div>`}
function tlCats(r){
  const d=(a,b)=>{const x=(b-a)*100;return `<b class="${x>=0.5?'pos':x<=-0.5?'neg':'muted'}">${x>=0?'+':''}${x.toFixed(1)}</b>`};
  const rows=r.me_cat.map((c,i)=>{const t=r.them_cat[i];
    return `<tr><td><b>${esc(c.cat)}</b></td><td>${(c.p0*100).toFixed(0)}% → ${(c.p1*100).toFixed(0)}%</td><td>${d(c.p0,c.p1)}</td><td class="muted">|</td><td>${(t.p0*100).toFixed(0)}% → ${(t.p1*100).toFixed(0)}%</td><td>${d(t.p0,t.p1)}</td></tr>`}).join('');
  return `<div class="tscroll"><table class="tl-tab"><thead><tr><th>Category</th><th colspan="2">You: chance to win it in a week</th><th></th><th colspan="2">${esc(r.partner)}</th></tr></thead><tbody>${rows}</tbody></table></div>
    <p class="sub" style="margin:6px 0 0">Chance to win each category against an average opponent, averaged over weeks ${esc(r.weeks.join(', '))} of real schedule. Change is in percentage points.</p>`}
function tlResult(LB,r){
  const exact=!r.lite;
  return `<div class="card" id="tlres"><h2>${tag(r.verdict)} ${esc(r.give.join(' + '))} <span class="muted">for</span> ${esc(r.get.join(' + '))}</h2>
    <p style="margin:0 0 10px">${tlVerdictText(r)}</p>
    <div class="tl-grid">
      <div class="tl-big"><div class="muted">Your power</div><div class="big2">${pct1(r.me_from)} → ${pct1(r.me_to)}</div><div class="${r.d_me>=0?'pos':'neg'}"><b>${sg(r.d_me)}</b> pts</div></div>
      <div class="tl-big"><div class="muted">${esc(r.partner)} (${esc(r.owner)})</div><div class="big2">${pct1(r.them_from)} → ${pct1(r.them_to)}</div><div class="${r.d_them>=0?'pos':'neg'}"><b>${sg(r.d_them)}</b> pts</div></div>
    </div>
    <p class="sub" style="margin:8px 0 12px">Power = average chance of beating each other team in a week, over weeks ${esc(r.weeks.join(', '))}.</p>
    <h3 class="tl-h">Why</h3><ul class="tl-ul">${tlWhy(LB,r).map(x=>`<li>${x}</li>`).join('')}</ul>
    <h3 class="tl-h">Players in the deal</h3>${tlPlayers(LB,r)}
    <h3 class="tl-h">Category by category</h3>${tlCats(r)}
    <p class="sub" style="margin:10px 0 0">${exact?'Computed with the full engine (same starts, positions, injuries and weekly cap as your matchup).':'Computed in your browser with a copy of the engine: tested within 0.05 pts of power against the full engine.'}
      The model that rated the rosters also judges the trade, so it likes its own picks: use it to find offers, then check injuries and news before you send one. Nothing is sent from here.</p></div>`}
function tlFinderRows(LB,rows){
  if(!rows.length)return '<div class="muted">Nobody has an offer that raises your power without costing them too much. Try sending a different player, or two together.</div>';
  const ce=l=>l.map(c=>`<span class="eff ${c.dz>0?'up':'down'}">${esc(c.cat)} ${c.dz>0?'▲':'▼'}</span>`).join('');
  return rows.map((r,i)=>`<div class="srow"><div class="top"><span>${tag(r.verdict)} <b>${esc(r.partner)}</b> <span class="muted">${esc(r.kind)} · ${esc(r.owner)}</span></span>
      <span>you <b class="${r.d_me>=0?'pos':'neg'}">${sg(r.d_me)}</b> · them <b class="${r.d_them>=0?'pos':'neg'}">${sg(r.d_them)}</b></span></div>
    <div style="margin:3px 0"><span class="muted">You give</span> <b>${esc(r.give.join(' + '))}</b> <span class="muted">· you get</span> <b>${esc(r.get.join(' + '))}</b></div>
    <div class="muted" style="font-size:12.5px">Your power ${pct1(r.me_from)} → ${pct1(r.me_to)} · theirs ${pct1(r.them_from)} → ${pct1(r.them_to)}${r.fill_me&&r.fill_me.length?' · you then add '+esc(r.fill_me.join(', ')):''}${r.drop_me&&r.drop_me.length?' · you then drop '+esc(r.drop_me.join(', ')):''}</div>
    <div><span class="muted">You:</span> ${ce(r.me_cats)||'<span class="muted">no big category change</span>'} <span class="muted">They:</span> ${ce(r.them_cats)||'<span class="muted">none</span>'}
      <button class="chipbtn" style="float:right" data-tl="open" data-i="${i}">Full analysis</button></div></div>`).join('')}
function renderTrade(){
  const el=$('#t-trade');if(!el)return;
  const LB=S.trades&&S.trades.lab;
  if(!LB){el.innerHTML='<div class="card muted">The trade lab is not available on this refresh (see the warnings under How it works).</div>';return}
  const me=LB.me,mine=LB.teams[me].players;
  if(!TR.partner||!LB.teams[TR.partner]||TR.partner===me)TR.partner=Object.keys(LB.teams).find(i=>i!==me);
  const theirs=LB.teams[TR.partner].players;
  TR.give=TR.give.filter(n=>mine.includes(n));TR.send=TR.send.filter(n=>mine.includes(n));TR.recv=TR.recv.filter(n=>theirs.includes(n));
  const opts=Object.keys(LB.teams).filter(i=>i!==me).map(i=>`<option value="${i}" ${i===TR.partner?'selected':''}>${esc(LB.teams[i].name)} (${esc(LB.teams[i].owner)})</option>`).join('');
  const finder=TR.finder?`<div style="margin-top:12px">${tlFinderRows(LB,TR.finder)}</div>`:'';
  el.innerHTML=`
  <div class="card"><h2>1 · Find the best partner</h2>
    <p class="sub" style="margin:0 0 8px">Tap the player(s) you want to trade away (one or two). The app searches every team for the 1-for-1, 1-for-2 and 2-for-1 packages that raise your power the most without wrecking theirs.</p>
    <div class="chips" id="tlgive">${mine.map(n=>tlChip(LB,n,TR.give.includes(n),'give')).join('')}</div>
    <div style="margin-top:10px"><button class="btn" id="tlfind" ${TR.give.length&&!TR.fbusy?'':'disabled'}>${TR.fbusy?'Searching…':'Find best partners'}</button> <span class="sub">${esc(TR.fmsg)}</span></div>${finder}</div>
  <div class="card"><h2>2 · Analyze a trade you type in</h2>
    <div class="toolbar"><label>Trade partner <select id="tlpartner">${opts}</select></label></div>
    <div class="tl-grid"><div><div class="sub" style="margin-bottom:4px"><b>You send</b> (tap your players)</div><div class="chips">${mine.map(n=>tlChip(LB,n,TR.send.includes(n),'send')).join('')}</div></div>
      <div><div class="sub" style="margin-bottom:4px"><b>You receive</b> (tap their players)</div><div class="chips">${theirs.map(n=>tlChip(LB,n,TR.recv.includes(n),'recv')).join('')}</div></div></div>
    <div style="margin-top:12px"><button class="btn" id="tlgo" ${TR.send.length&&TR.recv.length&&!TR.busy?'':'disabled'}>${TR.busy?'Analyzing…':'Analyze trade'}</button>
      <button class="btn ghost" id="tlclr">Clear</button> <span class="sub">${esc(TR.amsg)}</span></div></div>
  ${TR.res?tlResult(LB,TR.res):''}`;
  tlBind(LB);
}
function tlBind(LB){
  const el=$('#t-trade');
  el.onclick=e=>{const b=e.target.closest('[data-tl]');if(!b)return;const a=b.dataset.tl,n=b.dataset.n;
    const tog=k=>{const i=TR[k].indexOf(n);if(i>=0)TR[k].splice(i,1);else if(k==='give'&&TR.give.length>=2){TR.give.shift();TR.give.push(n)}else TR[k].push(n)};
    if(a==='give'){tog('give');TR.finder=null;TR.fmsg='';renderTrade()}
    else if(a==='send'){tog('send');renderTrade()}
    else if(a==='recv'){tog('recv');renderTrade()}
    else if(a==='open'){const r=TR.finder[+b.dataset.i];TR.partner=String(r.partner_id);TR.send=r.give.slice();TR.recv=r.get.slice();TR.res=null;renderTrade();tlRun(LB)}};
  const p=$('#tlpartner');if(p)p.onchange=()=>{TR.partner=p.value;TR.recv=[];TR.res=null;renderTrade()};
  $('#tlclr').onclick=()=>{TR.send=[];TR.recv=[];TR.res=null;TR.amsg='';renderTrade()};
  $('#tlgo').onclick=()=>tlRun(LB);
  $('#tlfind').onclick=()=>tlFind(LB);
}
async function tlRun(LB){
  TR.busy=true;TR.amsg='';renderTrade();
  await new Promise(r=>setTimeout(r,30));
  try{
    let res=null;
    if(MODE==='server'){
      try{res=await getJSON(`/api/trade_eval?partner=${encodeURIComponent(TR.partner)}&give=${encodeURIComponent(TR.send.join('|'))}&get=${encodeURIComponent(TR.recv.join('|'))}`);res.partner_id=String(res.partner_id)}
      catch(e){TR.amsg='Full engine unavailable ('+e.message+'); using the browser estimate.'}}
    if(!res)res=TL.analyze(LB,TR.partner,TR.send,TR.recv);
    TR.res=res;
  }catch(e){TR.res=null;TR.amsg=e.message}
  TR.busy=false;renderTrade();
  if(TR.res){const x=$('#tlres');if(x)x.scrollIntoView({behavior:'smooth',block:'start'})}
}
async function tlFind(LB){
  TR.fbusy=true;TR.finder=null;TR.fmsg=MODE==='server'?'Searching with the full engine, about 10-20 seconds…':'Searching…';renderTrade();
  await new Promise(r=>setTimeout(r,30));
  try{
    let rows=null;const bg=S.trades.by_give||{};
    if(MODE==='server'){try{rows=(await getJSON('/api/trade_search?give='+encodeURIComponent(TR.give.join('|')))).rows}catch(e){TR.fmsg='Full engine unavailable ('+e.message+'); using the browser search.'}}
    if(!rows&&TR.give.length===1&&bg[TR.give[0]]){rows=bg[TR.give[0]];TR.fmsg='Computed with the full engine at the last rebuild.'}
    if(!rows){rows=TL.search(LB,TR.give,2,12);if(!TR.fmsg||/Searching/.test(TR.fmsg))TR.fmsg='Computed in your browser (within 0.05 pts of the full engine).'}
    TR.finder=rows;
  }catch(e){TR.fmsg=e.message}
  TR.fbusy=false;renderTrade();
}
