"""Guards (2026-11-16, ideas #1 #2 #4): catch wrong numbers before they reach the page, and notice when the model drifts. Pure functions, no network.

  check_state(state, now=None)    #2 data sanity guard: impossible / stale / inconsistent values in the built state -> list of plain-English problems
  calibration_watch(preds)        #4 does '70-80%' mean 70-80%? reliability of the first-of-week forecasts after enough weeks -> list of flags
  selfcheck(df)                   #1 daily self-check on yesterday's started slots (needs p_play, projection, actual) -> list of flags

The engine only ADDS these to state['guards'] and the visible warnings; it never blocks a build (a blocked build would be worse than a flagged one)."""
import math
from datetime import datetime, timezone

STALE_MIN = 90          # in-season the cloud job runs every 5 min; a page older than this means the build or a feed has stalled


def _bad(x):
    return x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x)))


def check_state(state, now=None):
    out = []
    try:
        pw = state.get("p_win")
        if _bad(pw) or not (0.0 <= pw <= 1.0):
            out.append(f"win chance is not a probability ({pw})")
        cats = state.get("cats") or []
        if len(cats) != 13:
            out.append(f"{len(cats)} categories in the state, expected 13")
        for c in cats:
            for k in ("p", "me_proj", "opp_proj"):
                v = c.get(k)
                if _bad(v):
                    out.append(f"{c.get('label', c.get('key'))}: {k} is missing/NaN")
            p = c.get("p")
            if not _bad(p) and not (0.0 <= p <= 1.0):
                out.append(f"{c.get('label')}: category chance {p} outside 0-1")
            if not _bad(c.get("me_proj")) and c.get("me_proj") < 0:
                out.append(f"{c.get('label')}: negative projected total {c.get('me_proj'):.1f}")
        ec = state.get("exp_cats")
        if _bad(ec) or not (0.0 <= ec <= 13.0):
            out.append(f"expected categories won out of range ({ec})")
        elif not _bad(pw) and cats:
            if (ec >= 9.0 and pw < 0.30) or (ec <= 4.0 and pw > 0.70):    # 13 cats, 7 wins: these two numbers must tell the same story
                out.append(f"win chance {pw:.0%} contradicts expected categories {ec:.1f}")
        roster = state.get("roster") or []
        if not roster:
            out.append("my roster is empty in the state")
        names = [r.get("name") for r in roster]
        if len(set(names)) != len(names):
            out.append("duplicate player on my roster")
        for r in roster:
            p = r.get("p")
            if _bad(p) or not (0.0 <= p <= 1.0):
                out.append(f"{r.get('name')}: play chance {p} is not a probability")
            if r.get("src") in (None, "none"):
                out.append(f"{r.get('name')}: no projection behind him")
        asof = state.get("asof")
        if asof and not state.get("preseason"):
            try:
                t = datetime.strptime(asof, "%Y-%m-%d %H:%M UTC").replace(tzinfo=timezone.utc)
                age = ((now or datetime.now(timezone.utc)) - t).total_seconds() / 60.0
                if age > STALE_MIN:
                    out.append(f"page is {age:.0f} min old (built {asof}); a feed or the build has stalled")
            except ValueError:
                out.append(f"unreadable as-of time '{asof}'")
    except Exception as ex:                                              # a guard must never be the thing that breaks a build
        out.append(f"guard could not run ({type(ex).__name__})")
    return out


def calibration_watch(preds, min_weeks=3, min_cats=40, min_bin=30, n_se=2.5):
    """preds = predictions.json {'log': {mp: {'first': {p_win, p_cat}}}, 'results': {mp: {'won', 'cats'}}}. Returns flags; [] = nothing wrong or too little data."""
    flags = []
    log, res = (preds or {}).get("log", {}), (preds or {}).get("results", {})
    pairs = [(log[p]["first"], r) for p, r in res.items() if p in log and log[p].get("first")]
    if len(pairs) < min_weeks:
        return flags
    obs = [(f["p_cat"][c], y) for f, r in pairs for c, y in r["cats"].items() if c in f["p_cat"]]
    if len(obs) >= min_cats:
        for lo, hi, name in ((0.0, 0.35, "underdog categories (<35%)"), (0.35, 0.65, "toss-up categories (35-65%)"), (0.65, 1.01, "favourite categories (>65%)")):
            b = [(p, y) for p, y in obs if lo <= p < hi]
            if len(b) < min_bin:                                   # categories inside one week move together, so small bins overstate the evidence
                continue
            mp_, my = sum(p for p, _ in b) / len(b), sum(y for _, y in b) / len(b)
            se = math.sqrt(max(mp_ * (1 - mp_), 0.05) / len(b))
            if abs(my - mp_) > n_se * se:
                flags.append(f"{name}: said {mp_:.0%}, happened {my:.0%} over {len(b)} category-weeks (more than 2.5 standard errors off)")
    w = [(f["p_win"], r["won"]) for f, r in pairs]
    brier = sum((p - y) ** 2 for p, y in w) / len(w)
    if len(w) >= 5 and brier > 0.30:
        flags.append(f"win forecasts score {brier:.2f}, worse than a coin flip (0.25) over {len(w)} weeks")
    return flags


def selfcheck(rows, big_miss=2.5):
    """rows: iterable of dicts for yesterday's started slots: name, tag (injury tag that morning), p_play, played (0/1), err (composite error in units of a typical miss).
    Returns flags: healthy-tagged player who did not play, and misses far outside normal."""
    flags = []
    for r in rows:
        if not r.get("played") and str(r.get("tag", "ACTIVE")).upper() == "ACTIVE" and r.get("p_play", 0) >= 0.9:
            flags.append(f"{r['name']} was ACTIVE and rated {r['p_play']:.0%} to play but did not play")
        if r.get("played") and r.get("err", 0) >= big_miss:
            flags.append(f"{r['name']}: line was {r['err']:.1f}x a typical miss away from the projection")
    return flags
