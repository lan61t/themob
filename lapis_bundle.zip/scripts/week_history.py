"""Week-by-week record of the matchup forecast and WHY it moved.

Every refresh offers a snapshot (win chance, expected categories, each category's chance, both rosters with injury status, games played,
adds used, the cumulative path). A snapshot is kept when something changed (a roster, an injury status, games played, adds used, or the win
chance moved >= 1 point) and always for the first one of a week. Each kept snapshot gets a list of CAUSES, found by diffing it against the
previous one: your adds/drops (streaming / waiver moves), the opponent's moves, injury-status changes, real games played, or
'projection refresh' when nothing structural changed (new news, lines or schedule data feeding the model). The file lives in a folder the
cloud workflow already persists, so the record keeps growing all season. It never rewrites the past.
"""
import json
from pathlib import Path

MAX_PER_WEEK = 250


def _load(f):
    try:
        return json.loads(Path(f).read_text(encoding="utf-8-sig"))
    except Exception:
        return {"weeks": {}}


def _names(x):
    return sorted(x)


def causes(prev, cur):
    """Describe what changed between two snapshots (structural causes first)."""
    out = []
    pm, cm = set(prev["mine"]), set(cur["mine"])
    po, co = set(prev["opp"]), set(cur["opp"])
    if cm != pm:
        add, drop = sorted(cm - pm), sorted(pm - cm)
        kind = "streaming / waiver move" if cur.get("adds_used", 0) > prev.get("adds_used", 0) else "roster change (trade or drop)"
        out.append({"type": "you", "text": f"You: +{', '.join(add) or '-'} / -{', '.join(drop) or '-'} ({kind})"})
    if co != po:
        out.append({"type": "opp", "text": f"Opponent: +{', '.join(sorted(co - po)) or '-'} / -{', '.join(sorted(po - co)) or '-'}"})
    for who, key in (("yours", "mine"), ("opp", "opp")):
        for n in sorted(set(prev["inj"]) & set(cur["inj"])):
            if n in cur[key] and n in prev[key] and prev["inj"][n] != cur["inj"][n]:
                out.append({"type": "inj", "text": f"{n} ({who}): {prev['inj'][n]} → {cur['inj'][n]}"})
    dg_me, dg_op = cur.get("gp_me", 0) - prev.get("gp_me", 0), cur.get("gp_op", 0) - prev.get("gp_op", 0)
    if abs(dg_me) >= 0.5 or abs(dg_op) >= 0.5:
        out.append({"type": "games", "text": f"Games counted: you {dg_me:+.0f}, opponent {dg_op:+.0f} (real results came in)"})
    if prev.get("pts") and cur.get("pts") and (cur["pts"][0] != prev["pts"][0] or cur["pts"][1] != prev["pts"][1]) and not any(c["type"] == "games" for c in out):
        out.append({"type": "games", "text": f"Real results came in: points you {cur['pts'][0] - prev['pts'][0]:+.0f}, opponent {cur['pts'][1] - prev['pts'][1]:+.0f}"})
    if not out:
        out.append({"type": "model", "text": "Projection refresh: new news, lines or schedule data; no roster or injury change"})
    return out


def record(file, week_key, opp, snap):
    """Store `snap` for `week_key` if it differs from the last kept one. Returns True if kept."""
    d = _load(file)
    w = d["weeks"].setdefault(str(week_key), {"opp": opp, "snaps": []})
    w["opp"] = opp
    sn = w["snaps"]
    snap = dict(snap, mine=_names(snap["mine"]), opp=_names(snap["opp"]))
    if sn:
        prev = sn[-1]
        structural = (prev["mine"] != snap["mine"] or prev["opp"] != snap["opp"] or prev.get("adds_used") != snap.get("adds_used")
                      or any(prev["inj"].get(n) != snap["inj"].get(n) for n in set(snap["inj"]) & set(prev["inj"]))
                      or prev.get("pts") != snap.get("pts")
                      or abs(prev.get("gp_me", 0) - snap.get("gp_me", 0)) >= 0.5 or abs(prev.get("gp_op", 0) - snap.get("gp_op", 0)) >= 0.5)
        if not structural and abs(prev["p_win"] - snap["p_win"]) < 0.01:
            return False
        snap["causes"] = causes(prev, snap)
        snap["d_pwin"] = snap["p_win"] - prev["p_win"]
        snap["d_exp"] = snap["exp_cats"] - prev["exp_cats"]
        snap["movers"] = sorted(({"cat": c, "dp": snap["p_cat"][c] - prev["p_cat"].get(c, snap["p_cat"][c])} for c in snap["p_cat"]),
                                key=lambda m: -abs(m["dp"]))[:3]
        snap["movers"] = [m for m in snap["movers"] if abs(m["dp"]) >= 0.03]
    sn.append(snap)
    if len(sn) > MAX_PER_WEEK:                                       # keep the first, drop the oldest middle ones
        del sn[1:len(sn) - MAX_PER_WEEK + 1]
    Path(file).parent.mkdir(parents=True, exist_ok=True)
    Path(file).write_text(json.dumps(d), encoding="utf-8")
    return True


def view(file, current_week=None, max_events=40):
    """Compact form for the page: per week the first and latest forecast, how it moved, and the dated events with their causes."""
    d = _load(file)
    out = []
    for k, w in sorted(d["weeks"].items(), key=lambda kv: -int(kv[0])):
        sn = w["snaps"]
        if not sn:
            continue
        first, last = sn[0], sn[-1]
        ev = [{"ts": s["ts"], "p_win": s["p_win"], "exp": s["exp_cats"], "d_pwin": s["d_pwin"], "d_exp": s["d_exp"],
               "causes": [c["text"] for c in s["causes"]], "kinds": sorted({c["type"] for c in s["causes"]}), "movers": s.get("movers", [])}
              for s in sn[1:]]
        by_kind = {}
        for e in ev:                                                 # total win-chance change by cause type (a snapshot with several causes is split evenly)
            for kd in e["kinds"]:
                by_kind[kd] = by_kind.get(kd, 0.0) + e["d_pwin"] / len(e["kinds"])
        out.append({"week": int(k), "opp": w["opp"], "first": {"ts": first["ts"], "p_win": first["p_win"], "exp": first["exp_cats"]},
                    "last": {"ts": last["ts"], "p_win": last["p_win"], "exp": last["exp_cats"]}, "n": len(sn), "by_kind": by_kind,
                    "events": ev[-max_events:][::-1], "current": current_week is not None and int(k) == int(current_week)})
    return out
