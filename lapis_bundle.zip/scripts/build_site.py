"""Build the static web version of Lapis Daily into ./site (what GitHub Pages serves).

    python scripts/build_site.py [--out site]

Runs the whole pipeline once (ESPN league, injuries, schedule overlay, projections, every team, matchup, streaming, box scores for the
last few game days) and writes plain files: index.html (the same page the local app uses; it detects that there is no server and reads the
JSON files), data/state.json, data/dates.json, data/daily_<date>.json, a manifest and icons so it can be added to a phone's home screen.
Nothing here needs a login or a secret: the league is public and every source is a public ESPN feed.
"""
import json
import struct
import sys
import time
import zlib
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import inseason_daily as D  # noqa: E402
import inseason_live as L  # noqa: E402
import espn_site as ES  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = HERE.parent
REFRESH_SECONDS = 600
DAYS_BACK = 9


def png(size, bg=(43, 95, 217), fg=(255, 255, 255)):
    """A plain app icon: blue rounded square with a white ring and a bar (a stylised basketball), no image libraries needed."""
    rows = []
    c, r = (size - 1) / 2, size * 0.30
    for y in range(size):
        row = bytearray([0])
        for x in range(size):
            dx, dy = x - c, y - c
            inside = max(abs(dx), abs(dy)) <= size * 0.5 - 1 and (abs(dx) + abs(dy) <= size * 0.92 or (abs(dx) < size * 0.42 and abs(dy) < size * 0.42))
            d = (dx * dx + dy * dy) ** 0.5
            ring = abs(d - r) < size * 0.035
            bar = abs(dy) < size * 0.03 and d < r or abs(dx) < size * 0.03 and d < r
            px = fg if (ring or bar) else bg
            row += bytes(px + ((255,) if inside else (0,)))
        rows.append(bytes(row))
    raw = b"".join(rows)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


ICON_SVG = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="22" fill="#2b5fd9"/>'
            '<circle cx="50" cy="50" r="30" fill="none" stroke="#fff" stroke-width="4"/><path d="M50 20v60M20 50h60" stroke="#fff" stroke-width="4"/></svg>')
MANIFEST = {"name": "Lapis Daily", "short_name": "Lapis", "start_url": "./", "scope": "./", "display": "standalone", "background_color": "#0f1217",
            "theme_color": "#2b5fd9", "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
                                                {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
                                                {"src": "icon.svg", "sizes": "any", "type": "image/svg+xml"}]}


def main():
    out = Path(sys.argv[sys.argv.index("--out") + 1]) if "--out" in sys.argv else ROOT / "site"
    (out / "data").mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    (out / "index.html").write_text((HERE / "lapis_app_template.html").read_text(encoding="utf-8"), encoding="utf-8")
    (out / "manifest.webmanifest").write_text(json.dumps(MANIFEST), encoding="utf-8")
    (out / "icon.svg").write_text(ICON_SVG, encoding="utf-8")
    for s in (180, 192, 512):
        (out / f"icon-{s}.png").write_bytes(png(s))
    (out / ".nojekyll").write_text("", encoding="utf-8")

    st = L.build_state()
    st["build_seconds"], st["refresh_every"], st["static"] = round(time.time() - t0, 1), REFRESH_SECONDS, True
    (out / "data" / "state.json").write_text(json.dumps(L.jclean(st), allow_nan=False), encoding="utf-8")
    print(f"state built ({st['build_seconds']}s): week {st['week']['mp']}, P(win) {st['p_win']:.1%}, {len(st['actions'])} actions, "
          f"{st['league']['new_moves']} new moves")

    _, today = L.now_nba()
    espn = getattr(L.build_state, "last_espn", None)
    dates = []
    for k in range(DAYS_BACK, -1, -1):
        d = today - timedelta(days=k)
        try:
            if not any(g["done"] for g in ES.scoreboard(d)):
                continue
            res = D.build_daily(d, espn, st.get("need_cats"))
        except Exception as e:
            print("box score skipped", d, type(e).__name__, str(e)[:80])
            continue
        if res.get("players"):
            (out / "data" / f"daily_{d.isoformat()}.json").write_text(json.dumps(L.jclean(res), allow_nan=False), encoding="utf-8")
            dates.append(d.isoformat())
    (out / "data" / "dates.json").write_text(json.dumps({"dates": dates, "default": dates[-1] if dates else None, "today": today.isoformat()}),
                                             encoding="utf-8")
    print(f"box scores: {len(dates)} day(s) -> {dates[-3:]}; total {time.time() - t0:.0f}s; site at {out}")


if __name__ == "__main__":
    main()
