"""Inline the trade-lab browser code (tradelab_engine.js, tradelab_ui.js) into the page template at serve / build time."""
from pathlib import Path

HERE = Path(__file__).resolve().parent


def inline(html):
    for ph, f in (("/*TL_ENGINE*/", "tradelab_engine.js"), ("/*TL_UI*/", "tradelab_ui.js")):
        html = html.replace(ph, (HERE / f).read_text(encoding="utf-8"))
    return html
